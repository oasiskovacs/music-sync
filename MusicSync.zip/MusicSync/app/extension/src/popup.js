const api = typeof browser !== "undefined" ? browser : chrome;

const button = document.getElementById("export");
const statusEl = document.getElementById("status");

function setStatus(text, cls) {
  statusEl.textContent = text;
  statusEl.className = cls || "";
}

api.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "progress") {
    setStatus(`Loading tracks... ${msg.count}`);
  }
});

button.addEventListener("click", async () => {
  button.disabled = true;
  setStatus("Starting...");

  try {
    const [tab] = await api.tabs.query({ active: true, currentWindow: true });

    if (!tab || !tab.url || !tab.url.startsWith("https://music.youtube.com/")) {
      setStatus("Open a music.youtube.com tab first.", "error");
      return;
    }

    const res = await api.tabs.sendMessage(tab.id, { type: "export" });

    if (res && res.ok) {
      setStatus(`Done! ${res.count} tracks saved to ${res.filename}`, "ok");
    } else {
      setStatus((res && res.error) || "Something went wrong.", "error");
    }
  } catch (err) {
    setStatus(
      "Could not reach the page. Reload the YouTube Music tab (F5) and try again.",
      "error"
    );
  } finally {
    button.disabled = false;
  }
});
