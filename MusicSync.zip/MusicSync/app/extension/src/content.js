// YT Music Exporter - content script
// Runs inside music.youtube.com. When the popup asks, it scrolls the playlist until
// every track has loaded, builds the text and downloads it as a .txt file.

(function () {
  const api = typeof browser !== "undefined" ? browser : chrome;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const clean = (s) => (s || "").replace(/\s+/g, " ").trim();

  function getItems() {
    return Array.from(
      document.querySelectorAll("ytmusic-responsive-list-item-renderer")
    );
  }

  function getScroller() {
    // YouTube Music usually scrolls the whole window; if not, try the containers.
    const candidates = [
      document.scrollingElement,
      document.querySelector("ytmusic-app-layout"),
      document.querySelector("#content"),
    ].filter(Boolean);
    return (
      candidates.find((el) => el.scrollHeight > el.clientHeight + 50) ||
      document.scrollingElement
    );
  }

  // Scrolls to the bottom until the number of tracks stops growing.
  async function loadAll(onProgress) {
    const scroller = getScroller();
    let lastCount = -1;
    let stableRounds = 0;

    while (stableRounds < 5) {
      scroller.scrollTop = scroller.scrollHeight;
      window.scrollTo(0, document.body.scrollHeight);
      await sleep(1200);

      const count = getItems().length;
      if (onProgress) onProgress(count);

      if (count === lastCount) {
        stableRounds++;
      } else {
        stableRounds = 0;
        lastCount = count;
      }
    }

    scroller.scrollTop = 0;
    window.scrollTo(0, 0);
  }

  function parseItem(item) {
    const titleEl = item.querySelector("yt-formatted-string.title");
    const title = clean(titleEl && titleEl.textContent);

    // Secondary columns: normally [artist, album]
    const secondary = Array.from(
      item.querySelectorAll(".secondary-flex-columns yt-formatted-string")
    )
      .map((el) => clean(el.textContent))
      .filter(Boolean);

    const durationEl = item.querySelector(
      ".fixed-columns yt-formatted-string, .fixed-columns .title"
    );
    const duration = clean(durationEl && durationEl.textContent);

    return {
      title,
      artist: secondary[0] || "",
      album: secondary[1] || "",
      duration,
    };
  }

  function getPlaylistName() {
    const el = document.querySelector(
      "ytmusic-responsive-header-renderer h1 yt-formatted-string, " +
        "ytmusic-responsive-header-renderer .title, " +
        "ytmusic-detail-header-renderer .title"
    );
    const name = clean(el && el.textContent);
    return name || clean(document.title.replace(/- YouTube Music$/i, "")) || "playlist";
  }

  function buildText(name, tracks) {
    const lines = [];
    lines.push(`${name}`);
    lines.push(`${tracks.length} tracks - exported on ${new Date().toLocaleString("en-US")}`);
    lines.push("");

    tracks.forEach((t, i) => {
      const parts = [t.title, t.artist, t.album].filter(Boolean);
      lines.push(`${String(i + 1).padStart(3, "0")}. ${parts.join(" - ")}`);
    });

    return lines.join("\n") + "\n";
  }

  function download(filename, text) {
    // BOM so Windows Notepad shows accents correctly
    const blob = new Blob(["﻿", text], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }

  function safeFilename(name) {
    return (
      name
        .replace(/[\\/:*?"<>|]/g, "")
        .replace(/\s+/g, "_")
        .slice(0, 80) || "playlist"
    );
  }

  let running = false;

  async function exportPlaylist() {
    if (running) return { ok: false, error: "An export is already running." };

    if (getItems().length === 0) {
      return {
        ok: false,
        error:
          "No tracks found. Open a playlist (or Liked Songs) and make sure you are logged in.",
      };
    }

    running = true;
    try {
      await loadAll((n) => {
        try {
          api.runtime.sendMessage({ type: "progress", count: n });
        } catch (e) {
          /* popup closed: ignore */
        }
      });

      const tracks = getItems().map(parseItem).filter((t) => t.title);
      const name = getPlaylistName();
      const text = buildText(name, tracks);
      const filename = `${safeFilename(name)}.txt`;
      download(filename, text);

      return { ok: true, count: tracks.length, filename };
    } catch (err) {
      return { ok: false, error: String(err && err.message ? err.message : err) };
    } finally {
      running = false;
    }
  }

  api.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === "export") {
      return exportPlaylist();
    }
  });
})();
