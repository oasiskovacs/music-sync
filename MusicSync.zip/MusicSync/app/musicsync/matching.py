"""Normalisation, de-duplication and ranking of candidates (list -> YouTube)."""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, replace
from difflib import SequenceMatcher
from typing import Any, Dict, FrozenSet, Iterable, List, Optional

ACCEPT_THRESHOLD = 0.75
MAX_DURATION_DIFF = 15.0  # segundos

_BRACKETS = re.compile(r"[\(\[\{][^\)\]\}]*[\)\]\}]")
_FEAT_TAIL = re.compile(r"\s+(?:feat\.?|ft\.?|featuring)\s+.*$", re.IGNORECASE)
_DASH_SUFFIX = re.compile(
    r"\s+-\s+.*\b(?:remaster(?:ed)?|mono|stereo|deluxe|bonus track|radio edit|single version|album version|from)\b.*$",
    re.IGNORECASE,
)
_VERSION_RE = re.compile(
    r"\b(live|remix|acoustic|instrumental|karaoke|sped up|slowed|nightcore|8d|reverb|lo-?fi|mashup|cover|"
    r"tribute|demo|unplugged|extended|a cappella|acapella)\b"
)
_CHANNEL_SUFFIX = re.compile(r"\s*(?:-\s*topic|vevo)\s*$", re.IGNORECASE)


def _strip_accents(text: str) -> str:
    """Strips accents from Latin letters (keeps Japanese, Korean, etc.)."""
    out: List[str] = []
    for ch in unicodedata.normalize("NFKD", text):
        if unicodedata.category(ch) == "Mn" and out and ord(out[-1]) < 0x250:
            continue
        out.append(ch)
    return unicodedata.normalize("NFKC", "".join(out))


def normalize(text: Optional[str]) -> str:
    s = _strip_accents(text or "").casefold().replace("&", " and ")
    s = re.sub(r"[^\w\s]|_", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def clean_title(title: Optional[str]) -> str:
    """Title without (feat. ...), [brackets] and remaster suffixes."""
    raw = title or ""
    t = _BRACKETS.sub(" ", raw)
    t = _DASH_SUFFIX.sub("", t)
    t = _FEAT_TAIL.sub("", t)
    cleaned = normalize(t)
    return cleaned or normalize(raw)


def version_words(title: Optional[str]) -> FrozenSet[str]:
    """Words that signal another version of the song (live, remix, acoustic...)."""
    found = _VERSION_RE.findall(_strip_accents(title or "").casefold())
    return frozenset(w.replace("-", "") for w in found)


def track_key(artists: Iterable[str], title: str) -> str:
    artists = [a for a in artists if a]
    primary = normalize(artists[0]) if artists else "unknown artist"
    return f"{primary}|{clean_title(title)}|{'+'.join(sorted(version_words(title)))}"


def similarity(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    direct = SequenceMatcher(None, a, b).ratio()
    sa, sb = " ".join(sorted(a.split())), " ".join(sorted(b.split()))
    return max(direct, SequenceMatcher(None, sa, sb).ratio())


def _channel_name(name: str) -> str:
    return normalize(_CHANNEL_SUFFIX.sub("", name or ""))


def _candidate_titles(cand_title: str) -> List[str]:
    variants = [clean_title(cand_title)]
    if " - " in cand_title:  # "Artist - Title" (common in videos)
        variants.append(clean_title(cand_title.split(" - ", 1)[1]))
    return variants


def _duration_score(src: Optional[float], cand: Optional[float]) -> Optional[float]:
    """None = rejeitado. 0.5 = desconhecido."""
    if not src or not cand:
        return 0.5
    diff = abs(src - cand)
    if diff > MAX_DURATION_DIFF:
        return None
    if diff <= 2:
        return 1.0
    if diff <= 5:
        return 0.9
    if diff <= 10:
        return 0.6
    return 0.3


@dataclass
class ScoredCandidate:
    video_id: str
    score: float
    title: str
    artists: List[str]
    duration_s: Optional[float]
    video_type: Optional[str]


def score_candidate(track: Any, cand: Dict[str, Any]) -> Optional[float]:
    """Score from 0 to 1 for a YouTube Music search result. None = rejected."""
    cand_title = cand.get("title") or ""
    dur = _duration_score(track.duration_s, cand.get("duration_seconds"))
    if dur is None:
        return None

    title_score = max(similarity(clean_title(track.title), v) for v in _candidate_titles(cand_title))

    src = [normalize(a) for a in track.artists if a]
    cand_artists = [_channel_name(a.get("name", "")) for a in (cand.get("artists") or []) if a.get("name")]
    cand_title_norm = normalize(cand_title)

    def found(name: str) -> bool:
        return bool(name) and (any(similarity(name, c) >= 0.85 for c in cand_artists) or name in cand_title_norm)

    if not src:
        artist_score = 0.5
    elif found(src[0]):
        others = src[1:]
        frac = sum(found(a) for a in others) / len(others) if others else 1.0
        artist_score = 0.7 + 0.3 * frac
    elif any(found(a) for a in src[1:]):
        artist_score = 0.5
    else:
        artist_score = 0.0

    score = 0.45 * title_score + 0.30 * artist_score + 0.25 * dur

    wanted, got = version_words(track.title), version_words(cand_title)
    if got - wanted:
        score -= 0.4
    if wanted - got:
        score -= 0.3

    if track.explicit is not None and cand.get("isExplicit") is not None:
        score += 0.04 if bool(cand["isExplicit"]) == bool(track.explicit) else -0.04

    album = cand.get("album")
    album_name = album.get("name") if isinstance(album, dict) else album
    if track.album and album_name and similarity(normalize(track.album), normalize(album_name)) >= 0.9:
        score += 0.04

    vtype = cand.get("videoType") or ""
    if vtype.endswith("_ATV"):
        score += 0.04
    elif vtype.endswith("_UGC"):
        score -= 0.08

    # No cap at 1.0 on purpose: the bonuses (official audio, explicit, album) must break ties
    # between candidates that are already "perfect". The final score can reach ~1.1.
    return max(0.0, score)


def rank_candidates(track: Any, candidates: Iterable[Dict[str, Any]]) -> List[ScoredCandidate]:
    ranked: List[ScoredCandidate] = []
    for cand in candidates:
        vid = cand.get("videoId")
        if not vid:
            continue
        score = score_candidate(track, cand)
        if score is None:
            continue
        ranked.append(
            ScoredCandidate(
                video_id=vid,
                score=score,
                title=cand.get("title") or "",
                artists=[a.get("name", "") for a in (cand.get("artists") or [])],
                duration_s=cand.get("duration_seconds"),
                video_type=cand.get("videoType"),
            )
        )
    ranked.sort(key=lambda c: c.score, reverse=True)
    return ranked


_FILL_ATTRS = ("album", "duration_s", "explicit", "track_number", "disc_number", "year", "isrc", "cover_url", "spotify_id")


def merge_tracks(tracks: Iterable[Any]) -> List[Any]:
    """Merges repeated tracks (same key), preferring the Spotify metadata
    and keeping the YouTube Music video_id when there is one."""
    groups: Dict[str, List[Any]] = {}
    order: List[str] = []
    for t in tracks:
        k = t.key
        if k not in groups:
            groups[k] = []
            order.append(k)
        groups[k].append(t)

    merged_list: List[Any] = []
    for k in order:
        group = groups[k]
        base = next((t for t in group if "spotify" in t.sources), group[0])
        merged = replace(base, artists=list(base.artists), sources=[])
        for t in group:
            for s in t.sources:
                if s not in merged.sources:
                    merged.sources.append(s)
            if not merged.video_id and t.video_id:
                merged.video_id = t.video_id
                merged.video_type = t.video_type
            for attr in _FILL_ATTRS:
                if getattr(merged, attr) in (None, "") and getattr(t, attr) not in (None, ""):
                    setattr(merged, attr, getattr(t, attr))
        merged_list.append(merged)
    return merged_list
