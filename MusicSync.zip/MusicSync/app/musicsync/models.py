"""Shared data models."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Literal, Optional

from pydantic import BaseModel, Field, field_validator

Source = Literal["spotify", "ytmusic", "import"]


@dataclass
class Track:
    title: str
    artists: List[str]
    album: Optional[str] = None
    duration_s: Optional[float] = None
    explicit: Optional[bool] = None
    track_number: Optional[int] = None
    disc_number: Optional[int] = None
    year: Optional[str] = None
    isrc: Optional[str] = None
    cover_url: Optional[str] = None
    spotify_id: Optional[str] = None
    video_id: Optional[str] = None
    video_type: Optional[str] = None
    sources: List[str] = field(default_factory=list)

    @property
    def primary_artist(self) -> str:
        return self.artists[0] if self.artists else "Unknown Artist"

    @property
    def artist_text(self) -> str:
        return ", ".join(self.artists) if self.artists else "Unknown Artist"

    @property
    def key(self) -> str:
        from .matching import track_key

        return track_key(self.artists, self.title)

    def to_public(self) -> dict:
        return {
            "key": self.key,
            "title": self.title,
            "artists": list(self.artists),
            "album": self.album,
            "duration_s": self.duration_s,
            "sources": list(self.sources),
            "video_id": self.video_id,
            "spotify_id": self.spotify_id,
        }


class SyncRequest(BaseModel):
    """Body of POST /api/sync."""

    output_dir: str
    sources: List[Source] = Field(default_factory=lambda: ["spotify", "ytmusic"])
    ytmusic_include_library: bool = True
    ytmusic_include_liked: bool = True
    quality: Literal["320k", "256k", "192k", "128k", "V0"] = "320k"
    filename_template: str = "{artist} - {title}"
    limit: Optional[int] = Field(default=None, ge=1)
    dry_run: bool = False
    on_conflict: Literal["skip", "rename", "overwrite"] = "skip"
    workers: int = Field(default=2, ge=1, le=6)
    embed_cover: bool = True

    @field_validator("output_dir")
    @classmethod
    def _output_dir_not_empty(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("output_dir cannot be empty")
        return v

    @field_validator("sources")
    @classmethod
    def _sources_not_empty(cls, v: List[str]) -> List[str]:
        seen: List[str] = []
        for s in v:
            if s not in seen:
                seen.append(s)
        if not seen:
            raise ValueError("choose at least one source (spotify and/or ytmusic)")
        return seen

    @field_validator("filename_template")
    @classmethod
    def _template_valid(cls, v: str) -> str:
        from .naming import validate_template

        validate_template(v)
        return v
