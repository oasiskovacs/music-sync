"""Shared switch for YouTube's anti-bot check.

When YouTube answers a download with its "confirm you're not a bot" page (or HTTP 429), the program does not
try to solve or bypass anything. It waits:

* A blocked track is put on hold and the rest of the list keeps going.
* After `threshold` blocks in a row, every download pauses.
* After a cooldown, ONE download is let through as a probe. If it works, everything resumes. If it is blocked
  again, the cooldown grows (see `cooldowns`) and the pause continues.
* After `max_cycles` failed probes the guard gives up, so a job cannot hang forever.
"""
from __future__ import annotations

import threading
import time
from typing import Any, Callable, Dict, Optional, Sequence

from .youtube import DownloadCancelled

DEFAULT_COOLDOWNS = (120.0, 300.0, 600.0, 900.0, 1800.0)  # seconds; the last value repeats


class BotGuardGaveUp(RuntimeError):
    """YouTube kept blocking downloads for too long."""


class BotGuard:
    def __init__(
        self,
        threshold: int = 3,
        cooldowns: Sequence[float] = DEFAULT_COOLDOWNS,
        max_cycles: int = 12,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.threshold = threshold
        self.cooldowns = tuple(cooldowns) or (60.0,)
        self.max_cycles = max_cycles
        self._clock = clock
        self._cond = threading.Condition()
        self._consecutive = 0
        self._paused = False
        self._cycle = 0
        self._resume_at = 0.0
        self._probe_owner: Optional[int] = None
        self._gave_up = False

    def _cooldown(self) -> float:
        return self.cooldowns[min(self._cycle, len(self.cooldowns) - 1)]

    # ------------------------------------------------------------------ used before a download
    def wait_turn(self, cancel: Optional[threading.Event] = None) -> bool:
        """Blocks while paused. Returns True if the caller is the probe, False if downloads are running normally."""
        me = threading.get_ident()
        with self._cond:
            while True:
                if cancel is not None and cancel.is_set():
                    raise DownloadCancelled()
                if self._gave_up:
                    raise BotGuardGaveUp(
                        "YouTube kept blocking downloads (anti-bot check). Try again later, or let yt-dlp use your "
                        "browser's YouTube cookies (see the tutorial)."
                    )
                if not self._paused:
                    return False
                if self._probe_owner is None and self._clock() >= self._resume_at:
                    self._probe_owner = me
                    return True
                if self._probe_owner == me:
                    return True
                self._cond.wait(timeout=0.5)

    # ------------------------------------------------------------------ used after a download
    def record_success(self) -> bool:
        """Returns True if this success ended a pause."""
        with self._cond:
            self._consecutive = 0
            was_paused = self._paused
            self._paused = False
            self._probe_owner = None
            self._cycle = 0
            self._cond.notify_all()
            return was_paused

    def record_block(self) -> Dict[str, Any]:
        """Call when a download was blocked. Returns what happened, for logging."""
        me = threading.get_ident()
        with self._cond:
            self._consecutive += 1
            event: Dict[str, Any] = {"paused_now": False, "retry_in": None, "gave_up": False, "consecutive": self._consecutive}
            if self._paused and self._probe_owner == me:  # the probe failed
                self._cycle += 1
                self._probe_owner = None
                if self._cycle >= self.max_cycles:
                    self._gave_up = True
                    event["gave_up"] = True
                else:
                    self._resume_at = self._clock() + self._cooldown()
                    event["retry_in"] = self._cooldown()
            elif not self._paused and self._consecutive >= self.threshold:
                self._paused = True
                self._cycle = 0
                self._resume_at = self._clock() + self._cooldown()
                event["paused_now"] = True
                event["retry_in"] = self._cooldown()
            self._cond.notify_all()
            return event

    def release_probe(self) -> None:
        """The probe ended without a verdict (cancelled or failed for another reason): let someone else probe."""
        with self._cond:
            if self._probe_owner == threading.get_ident():
                self._probe_owner = None
                self._cond.notify_all()

    # ------------------------------------------------------------------ for the window
    def status(self) -> Dict[str, Any]:
        with self._cond:
            retry_in = max(0.0, self._resume_at - self._clock()) if self._paused and self._probe_owner is None else 0.0
            return {"paused": self._paused, "retry_in": retry_in, "probing": self._probe_owner is not None, "gave_up": self._gave_up}
