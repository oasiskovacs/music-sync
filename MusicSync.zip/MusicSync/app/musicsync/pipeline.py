"""Runs the whole flow: read lists -> drop duplicates -> find on YouTube -> download -> tag -> organise."""
from __future__ import annotations

import logging
import os
import shutil
import tempfile
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set

from .botguard import BotGuard
from .index import DownloadIndex
from .jobs import Job
from .matching import merge_tracks
from .media import MediaError, build_metadata, fetch_cover, find_binary, probe, write_tags
from .models import SyncRequest, Track
from .naming import render_path, unique_path
from .sources.spotify import SpotifyError
from .sources.ytmusic import YTMusicError
from .youtube import DownloadCancelled, classify_error, friendly_error, is_bot_block

log = logging.getLogger(__name__)

TMP_DIRNAME = ".musicsync-tmp"
MIN_AUDIO_SECONDS = 5.0
DURATION_WARN_SECONDS = 15.0


class _BotHold(Exception):
    """YouTube's anti-bot check blocked this track. It goes on hold and is retried later."""


class PipelineError(RuntimeError):
    """Error that stops the whole job (message is shown to the user)."""


@dataclass
class _Ctx:
    job: Job
    req: SyncRequest
    out_dir: Path
    tmp_root: Path
    index: DownloadIndex
    ffmpeg: Optional[str]
    ffprobe: Optional[str]
    max_component: int
    lock: threading.Lock = field(default_factory=threading.Lock)
    reserved: Set[Path] = field(default_factory=set)
    guard: BotGuard = field(default_factory=BotGuard)
    video_ids: Dict[str, str] = field(default_factory=dict)


class SyncPipeline:
    def __init__(
        self,
        settings: Any,
        spotify: Any,
        ytm: Any,
        resolver: Any,
        downloader: Any,
        http_session: Any = None,
        cover_fetcher: Callable[..., Any] = fetch_cover,
        imported: Any = None,
        hold_delay: float = 60.0,
        guard_factory: Callable[[], BotGuard] = BotGuard,
    ) -> None:
        self.settings = settings
        self.spotify = spotify
        self.ytm = ytm
        self.resolver = resolver
        self.downloader = downloader
        self._session = http_session
        self._cover_fetcher = cover_fetcher
        self.imported = imported
        self.hold_delay = hold_delay  # seconds before tracks on hold are retried
        self._guard_factory = guard_factory

    # ------------------------------------------------------------------ leitura
    def collect_tracks(
        self,
        sources: List[str],
        include_library: bool = True,
        include_liked: bool = True,
        limit: Optional[int] = None,
        log_fn: Optional[Callable[[str], None]] = None,
    ) -> List[Track]:
        say = log_fn or (lambda _m: None)
        collected: List[Track] = []
        if "spotify" in sources:
            if not self.spotify.is_authenticated():
                raise PipelineError("Spotify is not connected. Click 'Connect Spotify' (or untick the source).")
            say("Reading saved songs from Spotify...")
            try:
                items = self.spotify.saved_tracks(limit=limit)
            except SpotifyError as exc:
                raise PipelineError(str(exc)) from exc
            say(f"Spotify: {len(items)} songs")
            collected += items
        if "ytmusic" in sources:
            if not self.ytm.is_configured():
                raise PipelineError("YouTube Music is not connected. Paste the headers (or untick the source).")
            say("Reading your YouTube Music library...")
            try:
                items = self.ytm.fetch(include_library, include_liked, limit)
            except YTMusicError as exc:
                raise PipelineError(str(exc)) from exc
            say(f"YouTube Music: {len(items)} songs")
            collected += items
        if "import" in sources:
            if self.imported is None or self.imported.count() == 0:
                raise PipelineError("The imported list is empty. Use 'Import list' (or untick the source).")
            items = self.imported.load(limit)
            say(f"Imported list: {len(items)} songs")
            collected += items
        merged = merge_tracks(collected)
        if len(merged) != len(collected):
            say(f"{len(collected) - len(merged)} duplicates across sources were merged")
        if limit is not None:
            merged = merged[:limit]
        return merged

    # ------------------------------------------------------------------ job
    def run(self, job: Job, req: SyncRequest) -> None:
        out_dir = Path(os.path.expandvars(os.path.expanduser(req.output_dir))).resolve()
        ffmpeg = find_binary("ffmpeg", self.settings.ffmpeg_location)
        ffprobe = find_binary("ffprobe", self.settings.ffmpeg_location)
        if not req.dry_run:
            if not ffmpeg or not ffprobe:
                raise PipelineError(
                    "ffmpeg/ffprobe not found. Install ffmpeg (or set FFMPEG_LOCATION in .env)."
                )
            try:
                out_dir.mkdir(parents=True, exist_ok=True)
                with tempfile.NamedTemporaryFile(dir=out_dir):
                    pass
            except OSError as exc:
                raise PipelineError(f"Cannot write to the folder '{out_dir}': {exc}") from exc

        job.log(f"Destination folder: {out_dir}" + (" (simulation, nothing will be downloaded)" if req.dry_run else ""))
        tracks = self.collect_tracks(
            req.sources, req.ytmusic_include_library, req.ytmusic_include_liked, req.limit, job.log
        )
        if not tracks:
            job.log("No songs found in the selected sources.")
            return
        job.log(f"{len(tracks)} songs to process")
        for t in tracks:
            job.add_item(t.key, t.title, t.artist_text, t.sources)

        max_component = 150
        if os.name == "nt":  # Windows limits the full path to 260 characters
            max_component = max(40, min(150, 240 - len(str(out_dir)) - 5))
        ctx = _Ctx(
            job=job,
            req=req,
            out_dir=out_dir,
            tmp_root=out_dir / TMP_DIRNAME,
            index=DownloadIndex(out_dir),
            ffmpeg=ffmpeg,
            ffprobe=ffprobe,
            max_component=max_component,
            guard=self._guard_factory(),
        )
        job.guard = ctx.guard
        try:
            held = self._run_pass(ctx, tracks)
            while held and not job.is_cancelled():
                job.log(f"{len(held)} track(s) on hold because of YouTube's anti-bot check; retrying in {self.hold_delay:.0f}s")
                if job.cancel_event.wait(self.hold_delay):
                    break
                held = self._run_pass(ctx, held)
            for t in held:  # only reached when cancelled
                job.update_item(t.key, status="cancelled", message="cancelled")
        finally:
            ctx.index.flush(force=True)
            self._cleanup_tmp(ctx)
            self._write_report(job)
        snap = job.snapshot(items="none")["counts"]
        job.log("Resumo: " + ", ".join(f"{k}={v}" for k, v in sorted(snap.items())))

    def _run_pass(self, ctx: _Ctx, tracks: List[Track]) -> List[Track]:
        """Processes the tracks once. Returns the ones that were put on hold."""
        with ThreadPoolExecutor(max_workers=ctx.req.workers, thread_name_prefix="dl") as pool:
            futures = [pool.submit(self._process, ctx, t) for t in tracks]
            results = [f.result() for f in futures]
        return [t for t, on_hold in zip(tracks, results) if on_hold]

    def _cleanup_tmp(self, ctx: _Ctx) -> None:
        try:
            if ctx.tmp_root.exists() and not any(ctx.tmp_root.iterdir()):
                ctx.tmp_root.rmdir()
        except OSError:
            pass

    def _write_report(self, job: Job) -> None:
        try:
            import json

            reports = self.settings.reports_dir
            reports.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
            (reports / f"{stamp}-{job.id[:8]}.json").write_text(
                json.dumps(job.snapshot(items="all"), ensure_ascii=False, indent=1), encoding="utf-8"
            )
        except Exception:  # noqa: BLE001 - the report is an extra and must never break the job
            log.warning("could not write the job report", exc_info=True)

    # ------------------------------------------------------------------ track
    def _process(self, ctx: _Ctx, track: Track) -> bool:
        """Returns True if the track was put on hold (anti-bot check)."""
        job, key = ctx.job, track.key
        if job.is_cancelled():
            job.update_item(key, status="cancelled", message="cancelled")
            return False
        try:
            self._process_inner(ctx, track)
        except _BotHold:
            job.update_item(key, status="on_hold", message="YouTube anti-bot check; will retry later")
            return True
        except DownloadCancelled:
            job.update_item(key, status="cancelled", message="cancelled")
        except Exception as exc:  # noqa: BLE001 - one failing track must not take down the others
            log.exception("failure on %s", track.title)
            job.update_item(key, status="failed", message=friendly_error(exc))
        return False

    def _process_inner(self, ctx: _Ctx, track: Track) -> None:
        job, req, key = ctx.job, ctx.req, track.key

        # 1) already downloaded before (index)?
        if req.on_conflict != "overwrite":
            existing = ctx.index.existing_file(key)
            if existing is not None:
                job.update_item(
                    key, status="skipped", message="already downloaded", file=existing.relative_to(ctx.out_dir).as_posix()
                )
                return

        # 2) destination path + conflict policy
        rel = render_path(req.filename_template, track, ctx.max_component)
        dest = ctx.out_dir / rel
        with ctx.lock:
            if dest in ctx.reserved:  # another track in this same run uses that name
                dest = unique_path(dest, ctx.reserved)
            elif dest.exists():
                if req.on_conflict == "skip":
                    job.update_item(key, status="skipped", message="a file with that name already exists", file=rel.as_posix())
                    return
                if req.on_conflict == "rename":
                    dest = unique_path(dest, ctx.reserved)
            ctx.reserved.add(dest)

        # 3) find the video
        video_id = track.video_id or ctx.video_ids.get(key)
        match_info = ""
        if not video_id:
            job.update_item(key, status="resolving", message="searching YouTube...")
            match = self.resolver.resolve(track)
            if match is None:
                job.update_item(key, status="not_found", message="no matching version found on YouTube")
                return
            video_id = match.video_id
            ctx.video_ids[key] = video_id
            match_info = f"{match.title} (score {match.score:.2f})"

        if req.dry_run:
            job.update_item(
                key,
                status="would_download",
                message=match_info or "already has a YouTube Music videoId",
                file=dest.relative_to(ctx.out_dir).as_posix(),
            )
            return

        # 4) download + convert
        ctx.tmp_root.mkdir(parents=True, exist_ok=True)
        work = Path(tempfile.mkdtemp(prefix="dl-", dir=str(ctx.tmp_root)))
        try:
            try:
                downloaded = self._download_with_retry(ctx, track, video_id, work)
            except _BotHold:
                with ctx.lock:
                    ctx.reserved.discard(dest)  # the retry must get the same file name back
                raise
            job.update_item(key, status="tagging", message="checking and writing tags...")

            assert ctx.ffprobe and ctx.ffmpeg
            info = probe(downloaded.path, ctx.ffprobe)
            duration = float(info["duration"] or 0)  # type: ignore[arg-type]
            if duration < MIN_AUDIO_SECONDS:
                raise MediaError("the downloaded audio is too short to be a song")
            warnings: List[str] = []
            if track.duration_s and abs(duration - track.duration_s) > DURATION_WARN_SECONDS:
                warnings.append(
                    f"length differs from expected ({duration:.0f}s vs {track.duration_s:.0f}s): check that it is the right version"
                )

            cover = None
            if req.embed_cover and track.cover_url:
                cover = self._cover_fetcher(track.cover_url, self._session)

            final = work / "final.mp3"
            try:
                write_tags(ctx.ffmpeg, downloaded.path, final, build_metadata(track), cover)
            except MediaError:
                try:  # try again without the cover
                    write_tags(ctx.ffmpeg, downloaded.path, final, build_metadata(track), None)
                    warnings.append("could not embed the cover art")
                except MediaError as exc:
                    warnings.append(f"tags not written: {exc}")
                    final = downloaded.path

            dest.parent.mkdir(parents=True, exist_ok=True)
            try:
                os.replace(final, dest)
            except OSError:
                shutil.move(str(final), str(dest))
        finally:
            shutil.rmtree(work, ignore_errors=True)

        rel_done = dest.relative_to(ctx.out_dir).as_posix()
        ctx.index.record(
            key,
            file=rel_done,
            video_id=video_id,
            spotify_id=track.spotify_id,
            sources=list(track.sources),
            title=track.title,
            artists=list(track.artists),
            downloaded_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        )
        source_desc = ""
        if downloaded.acodec and downloaded.acodec != "none":
            kbps = f" {downloaded.abr:.0f} kbps" if downloaded.abr else ""
            source_desc = f"source {downloaded.acodec}{kbps} → "
        bitrate = f"{int(info['bit_rate']) // 1000} kbps" if info.get("bit_rate") else req.quality  # type: ignore[arg-type]
        job.update_item(
            key,
            status="done",
            message=f"{source_desc}MP3 {bitrate}",
            file=rel_done,
            warnings=warnings,
        )

    def _download_with_retry(self, ctx: _Ctx, track: Track, video_id: str, work: Path) -> Any:
        job, key, guard = ctx.job, track.key, ctx.guard

        def on_progress(pct: float) -> None:
            job.update_item(key, status="downloading", message=f"downloading {pct:.0f}%")

        for attempt in (1, 2):
            guard.wait_turn(job.cancel_event)  # blocks while the anti-bot pause is active
            job.update_item(key, status="downloading", message="downloading...")
            try:
                result = self.downloader.download(
                    video_id, work, ctx.req.quality, cancel=job.cancel_event, progress=on_progress
                )
            except DownloadCancelled:
                guard.release_probe()
                raise
            except Exception as exc:  # noqa: BLE001
                if is_bot_block(exc):
                    self._announce_block(ctx, guard.record_block())
                    raise _BotHold() from exc
                guard.release_probe()
                _msg, permanent = classify_error(exc)
                if permanent or attempt == 2:
                    raise
                job.update_item(key, message="failed, trying again...")
                time.sleep(3)
            else:
                if guard.record_success():
                    job.log("YouTube accepted a download again. Resuming.")
                return result
        raise RuntimeError("unreachable")  # pragma: no cover

    def _announce_block(self, ctx: _Ctx, event: Dict[str, Any]) -> None:
        if event["gave_up"]:
            ctx.job.log("YouTube is still blocking downloads. Giving up on the tracks that are on hold.")
        elif event["paused_now"]:
            ctx.job.log(
                f"YouTube's anti-bot check blocked {event['consecutive']} downloads in a row. "
                f"Pausing all downloads; next try in {event['retry_in'] / 60:.0f} min."
            )
        elif event["retry_in"] is not None:
            ctx.job.log(f"Still blocked. Next try in {event['retry_in'] / 60:.0f} min.")
