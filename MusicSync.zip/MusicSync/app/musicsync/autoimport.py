"""Imports on its own, at startup, the lists found in the `import/` folder (txt, csv or json)."""
from __future__ import annotations

import logging
import threading
from pathlib import Path
from typing import Any, Dict, List

from .sources.imported import ImportListError

log = logging.getLogger(__name__)

EXTENSIONS = {".txt", ".csv", ".json", ".tsv"}
DONE_SUFFIX = ".imported"
MAX_PASSES = 3


class AutoImporter:
    def __init__(self, imported: Any, folder: Path) -> None:
        self.imported = imported
        self.folder = Path(folder)
        self._lock = threading.Lock()
        self._state: Dict[str, Any] = {"state": "idle", "message": "", "files": 0}
        self._thread: threading.Thread | None = None

    def status(self) -> Dict[str, Any]:
        with self._lock:
            return dict(self._state)

    def _set(self, **fields: Any) -> None:
        with self._lock:
            self._state.update(fields)

    def pending_files(self) -> List[Path]:
        if not self.folder.is_dir():
            return []
        return sorted(p for p in self.folder.iterdir() if p.is_file() and p.suffix.lower() in EXTENSIONS)

    def start(self) -> None:
        if self._thread is not None:
            return
        self._thread = threading.Thread(target=self.run, name="autoimport", daemon=True)
        self._thread.start()

    def run(self) -> None:
        files = self.pending_files()
        if not files:
            self._set(state="idle", files=0)
            return
        self._set(state="running", files=len(files), message="Reading your list…")
        problems: List[str] = []
        for path in files:
            try:
                text = path.read_text(encoding="utf-8-sig", errors="replace")
            except OSError as exc:
                problems.append(f"{path.name}: {exc}")
                continue
            complete = False
            for _ in range(MAX_PASSES):
                try:
                    result = self.imported.add_text(text, "append")
                except ImportListError as exc:
                    problems.append(f"{path.name}: {exc}")
                    break
                except Exception as exc:  # noqa: BLE001 - must never take the program down
                    log.exception("failed to import %s", path)
                    problems.append(f"{path.name}: {exc}")
                    break
                if not result["links_failed"]:
                    complete = True
                    break
            else:
                problems.append(f"{path.name}: some songs could not be read; will try again the next time the program opens")
            if complete:
                try:
                    path.rename(path.with_name(path.name + DONE_SUFFIX))
                except OSError:
                    log.warning("could not rename %s", path, exc_info=True)
        if problems:
            self._set(state="error", message=" | ".join(problems))
        else:
            self._set(state="done", message="Lista lida.")
