"""The program window (Tkinter). Logic lives in core.AppController; this file only has buttons and text."""
from __future__ import annotations

import logging
import os
import sys
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from .config import QUALITY_MAP, load_settings
from .core import AppController, build_core

log = logging.getLogger(__name__)
TICK_MS = 700


class App:
    def __init__(self, controller: AppController) -> None:
        self.c = controller
        self.root = tk.Tk()
        self.root.title("Music Sync")
        try:  # window icon; carry on without it if the file is missing
            icon = Path(__file__).resolve().parent.parent / "assets" / "icon.ico"
            if icon.is_file() and sys.platform == "win32":
                self.root.iconbitmap(default=str(icon))
        except Exception:
            logging.getLogger(__name__).debug("no window icon", exc_info=True)
        self.root.geometry("780x620")
        self.root.minsize(660, 500)
        self.root.report_callback_exception = self._on_callback_error
        self.folder_var = tk.StringVar(value=self.c.prefs["output_dir"])
        self.quality_var = tk.StringVar(value=self.c.prefs["quality"])
        self.dry_var = tk.BooleanVar(value=False)
        self.add_win = None
        self.add_text = None
        self.add_status = None
        self._last_lines = None
        self._build()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self._tick()

    # ------------------------------------------------------------------ montagem
    def _build(self) -> None:
        frame = ttk.Frame(self.root, padding=14)
        frame.pack(fill="both", expand=True)

        self.lbl_list = ttk.Label(frame, text="", font=("Segoe UI", 15, "bold"))
        self.lbl_list.pack(anchor="w")
        self.lbl_warn = ttk.Label(frame, text="", foreground="#b00020", wraplength=720, justify="left")
        self.lbl_warn.pack(anchor="w", pady=(4, 0))

        row = ttk.Frame(frame)
        row.pack(fill="x", pady=(14, 4))
        ttk.Label(row, text="Destination folder:").pack(side="left")
        ttk.Entry(row, textvariable=self.folder_var).pack(side="left", fill="x", expand=True, padx=8)
        ttk.Button(row, text="Change…", command=self._pick_folder).pack(side="left")

        opts = ttk.Frame(frame)
        opts.pack(fill="x", pady=4)
        ttk.Label(opts, text="MP3 quality:").pack(side="left")
        ttk.Combobox(opts, textvariable=self.quality_var, values=list(QUALITY_MAP), state="readonly", width=6).pack(
            side="left", padx=8
        )
        ttk.Checkbutton(opts, text="Simulate only (downloads nothing)", variable=self.dry_var).pack(side="left", padx=16)

        buttons = ttk.Frame(frame)
        buttons.pack(fill="x", pady=(10, 6))
        self.btn_start = ttk.Button(buttons, text="Download all", command=self._start)
        self.btn_start.pack(side="left", ipadx=18, ipady=6)
        self.btn_cancel = ttk.Button(buttons, text="Cancel", command=self.c.cancel, state="disabled")
        self.btn_cancel.pack(side="left", padx=8, ipady=6)
        ttk.Button(buttons, text="Add songs…", command=self._open_add).pack(side="right", ipady=6)
        self.btn_clear = ttk.Button(buttons, text="Clear list", command=self._clear)
        self.btn_clear.pack(side="right", padx=8, ipady=6)

        self.progress = ttk.Progressbar(frame, mode="determinate", maximum=100)
        self.progress.pack(fill="x", pady=(10, 2))
        self.lbl_progress = ttk.Label(frame, text="")
        self.lbl_progress.pack(anchor="w")
        self.lbl_summary = ttk.Label(frame, text="")
        self.lbl_summary.pack(anchor="w")

        box = ttk.Frame(frame)
        box.pack(fill="both", expand=True, pady=(8, 0))
        self.txt = tk.Text(box, height=12, wrap="word", state="disabled")
        scroll = ttk.Scrollbar(box, command=self.txt.yview)
        self.txt.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.txt.pack(side="left", fill="both", expand=True)

    # ------------------------------------------------------------------ actions
    def _pick_folder(self) -> None:
        current = self.folder_var.get().strip()
        initial = current if current and os.path.isdir(current) else str(Path.home())
        chosen = filedialog.askdirectory(title="Choose the folder for your songs", initialdir=initial)
        if chosen:
            self.folder_var.set(os.path.normpath(chosen))

    def _start(self) -> None:
        try:
            self.c.start(self.folder_var.get(), self.quality_var.get(), bool(self.dry_var.get()))
        except ValueError as exc:
            messagebox.showwarning("Music Sync", str(exc))
        self._last_lines = None

    def _clear(self) -> None:
        if messagebox.askyesno("Music Sync", "Delete the whole saved song list?"):
            self.c.clear_list()

    def _open_add(self) -> None:
        if self.add_win is not None:
            self.add_win.lift()
            return
        win = tk.Toplevel(self.root)
        win.title("Add songs")
        win.geometry("640x420")
        self.add_win = win
        win.protocol("WM_DELETE_WINDOW", self._close_add)
        body = ttk.Frame(win, padding=12)
        body.pack(fill="both", expand=True)
        ttk.Label(
            body,
            text=(
                "In the Spotify app: open Liked Songs, click a song, press Ctrl+A, then Ctrl+C, and paste here.\n"
                "Also accepted: lines like \"Artist - Title\", CSV or JSON (or choose a file)."
            ),
            justify="left",
            wraplength=600,
        ).pack(anchor="w")
        self.add_text = tk.Text(body, height=12, wrap="none")
        self.add_text.pack(fill="both", expand=True, pady=8)
        row = ttk.Frame(body)
        row.pack(fill="x")
        ttk.Button(row, text="Choose file…", command=self._load_file).pack(side="left")
        ttk.Button(row, text="Import", command=self._do_import).pack(side="left", padx=8)
        ttk.Button(row, text="Close", command=self._close_add).pack(side="right")
        self.add_status = ttk.Label(body, text="", wraplength=600, justify="left")
        self.add_status.pack(anchor="w", pady=(8, 0))

    def _close_add(self) -> None:
        if self.add_win is not None:
            self.add_win.destroy()
        self.add_win = self.add_text = self.add_status = None

    def _load_file(self) -> None:
        path = filedialog.askopenfilename(
            title="Choose the file with your songs",
            filetypes=[("Lists", "*.txt *.csv *.json *.tsv"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8-sig", errors="replace") as fh:
                content = fh.read()
        except OSError as exc:
            messagebox.showerror("Music Sync", f"Could not read the file: {exc}")
            return
        self.add_text.delete("1.0", "end")
        self.add_text.insert("1.0", content)

    def _do_import(self) -> None:
        try:
            self.c.add_text_async(self.add_text.get("1.0", "end"))
        except ValueError as exc:
            self.add_status.config(text=str(exc))
            return
        self.add_status.config(text="Reading… (many Spotify links can take a few minutes; progress is shown in the main window)")

    def _on_close(self) -> None:
        job = self.c.job
        if job is not None and job.is_active:
            if not messagebox.askyesno("Music Sync", "A download is running. Cancel it and quit?"):
                return
            self.c.cancel()
        self.root.destroy()

    def _on_callback_error(self, exc_type, exc, tb) -> None:
        log.error("window error", exc_info=(exc_type, exc, tb))
        messagebox.showerror("Music Sync", f"Something went wrong: {exc}\n\nDetails in musicsync.log")

    # ------------------------------------------------------------------ periodic refresh
    def _set_lines(self, lines) -> None:
        text = "\n".join(lines)
        if text == self._last_lines:
            return
        self._last_lines = text
        self.txt.config(state="normal")
        self.txt.delete("1.0", "end")
        self.txt.insert("1.0", text)
        self.txt.config(state="disabled")

    def _tick(self) -> None:
        try:
            state = self.c.library_state()
            self.lbl_list.config(text=state["text"])
            warnings = self.c.warnings()
            if state["problem"]:
                warnings = warnings + [state["problem"]]
            self.lbl_warn.config(text="\n".join(warnings))

            view = self.c.job_view()
            active = bool(view and view["active"])
            self.btn_start.config(state="normal" if state["can_start"] else "disabled")
            self.btn_cancel.config(state="normal" if active else "disabled")
            self.btn_clear.config(state="disabled" if (active or state["busy"]) else "normal")
            if view:
                self.progress.config(value=view["percent"])
                self.lbl_progress.config(text=view["status_text"])
                self.lbl_summary.config(text=view["summary"])
                self._set_lines(view["lines"] or view["log"])

            result = self.c.poll_add_result()
            if result is not None and self.add_status is not None:
                self.add_status.config(text=result[1])
        finally:
            self.root.after(TICK_MS, self._tick)


def run_gui(project_dir: Path) -> None:
    try:  # sharp text on high-DPI screens in Windows
        import ctypes

        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:  # noqa: BLE001 - Windows only
        pass
    settings = load_settings()
    core = build_core(settings, Path(project_dir) / "import")
    if core.auto is not None:
        core.auto.start()
    app = App(AppController(core))
    app.root.mainloop()
