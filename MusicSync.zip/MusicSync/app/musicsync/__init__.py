"""Music Sync: turns your Spotify / YouTube Music song lists into tagged MP3 files."""

__version__ = "1.0.0"
