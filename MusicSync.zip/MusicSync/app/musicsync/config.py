"""Configuration through environment variables / a .env file."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Optional

# quality -> yt-dlp `preferredquality` value (>=10 = CBR kbps, <10 = LAME VBR)
QUALITY_MAP = {"320k": "320", "256k": "256", "192k": "192", "128k": "128", "V0": "0"}
DEFAULT_QUALITY = "320k"


class ConfigError(ValueError):
    """Invalid value in a configuration variable."""


@dataclass(frozen=True)
class Settings:
    home: Path
    host: str
    port: int
    spotify_client_id: str
    spotify_redirect_uri: str
    ffmpeg_location: Optional[str]
    cookies_file: Optional[str]
    cookies_from_browser: Optional[str]
    js_runtime: Optional[str]
    remote_components: tuple
    default_output_dir: Optional[str]
    default_quality: str
    default_workers: int

    @property
    def ytm_auth_file(self) -> Path:
        return self.home / "ytmusic_auth.json"

    @property
    def spotify_token_file(self) -> Path:
        return self.home / "spotify_token.json"

    @property
    def reports_dir(self) -> Path:
        return self.home / "reports"


def _int(env: Mapping[str, str], name: str, default: int, lo: int, hi: int) -> int:
    raw = (env.get(name) or "").strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise ConfigError(f"{name} must be a whole number (got: {raw!r})") from exc
    if not lo <= value <= hi:
        raise ConfigError(f"{name} must be between {lo} and {hi} (got: {value})")
    return value


def _opt(env: Mapping[str, str], name: str) -> Optional[str]:
    raw = (env.get(name) or "").strip()
    return raw or None


def load_settings(env: Optional[Mapping[str, str]] = None, load_env_file: bool = True) -> Settings:
    """Reads the settings. In tests, pass `env` and `load_env_file=False`."""
    if env is None:
        if load_env_file:
            try:
                from dotenv import find_dotenv, load_dotenv

                load_dotenv(find_dotenv(usecwd=True), override=False)
            except ImportError:  # python-dotenv is optional in practice
                pass
        env = os.environ

    port = _int(env, "PORT", 8000, 1, 65535)
    quality = _opt(env, "MP3_QUALITY") or DEFAULT_QUALITY
    if quality not in QUALITY_MAP:
        raise ConfigError(f"MP3_QUALITY must be one of {', '.join(QUALITY_MAP)} (got: {quality!r})")

    home = Path(_opt(env, "MUSICSYNC_HOME") or "~/.musicsync").expanduser()
    host = _opt(env, "HOST") or "127.0.0.1"
    components = tuple(c.strip() for c in (_opt(env, "YTDLP_REMOTE_COMPONENTS") or "").split(",") if c.strip())

    return Settings(
        home=home,
        host=host,
        port=port,
        spotify_client_id=_opt(env, "SPOTIFY_CLIENT_ID") or "",
        spotify_redirect_uri=_opt(env, "SPOTIFY_REDIRECT_URI") or f"http://127.0.0.1:{port}/auth/spotify/callback",
        ffmpeg_location=_opt(env, "FFMPEG_LOCATION"),
        cookies_file=_opt(env, "YTDLP_COOKIES_FILE"),
        cookies_from_browser=_opt(env, "YTDLP_COOKIES_FROM_BROWSER"),
        js_runtime=_opt(env, "YTDLP_JS_RUNTIME"),
        remote_components=components,
        default_output_dir=_opt(env, "DEFAULT_OUTPUT_DIR") or str(Path.home() / "Music" / "MusicSync"),
        default_quality=quality,
        default_workers=_int(env, "WORKERS", 2, 1, 6),
    )
