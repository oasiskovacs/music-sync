"""Minimal Spotify API client (OAuth PKCE + saved songs), with no dependencies beyond `requests`."""
from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import secrets
import threading
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional
from urllib.parse import urlencode

import requests

from ..models import Track

log = logging.getLogger(__name__)

AUTH_URL = "https://accounts.spotify.com/authorize"
TOKEN_URL = "https://accounts.spotify.com/api/token"
API_BASE = "https://api.spotify.com/v1"
SCOPE = "user-library-read"
PAGE_SIZE = 50
STATE_TTL = 600  # segundos


class SpotifyError(RuntimeError):
    """Spotify authentication or API error (the message is shown to the user)."""


def _pkce_challenge(verifier: str) -> str:
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


class SpotifyClient:
    def __init__(
        self,
        client_id: str,
        redirect_uri: str,
        token_file: Path,
        session: Optional[requests.Session] = None,
        clock: Callable[[], float] = time.time,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self.client_id = client_id
        self.redirect_uri = redirect_uri
        self.token_file = Path(token_file)
        self.session = session or requests.Session()
        self._clock = clock
        self._sleep = sleep
        self._lock = threading.RLock()
        self._pending: Dict[str, Dict[str, float]] = {}
        self._token: Optional[dict] = None

    # ---------- estado ----------
    @property
    def configured(self) -> bool:
        return bool(self.client_id)

    def is_authenticated(self) -> bool:
        if not self.configured:
            return False
        token = self._load_token()
        return bool(token and token.get("refresh_token"))

    def logout(self) -> None:
        with self._lock:
            self._token = None
            try:
                self.token_file.unlink()
            except FileNotFoundError:
                pass

    # ---------- login (PKCE) ----------
    def authorize_url(self) -> str:
        if not self.configured:
            raise SpotifyError("SPOTIFY_CLIENT_ID is not set. See the README (Spotify step).")
        verifier = secrets.token_urlsafe(64)
        state = secrets.token_urlsafe(16)
        now = self._clock()
        with self._lock:
            self._pending = {s: v for s, v in self._pending.items() if now - v["created"] < STATE_TTL}
            self._pending[state] = {"verifier": verifier, "created": now}  # type: ignore[dict-item]
        query = urlencode(
            {
                "client_id": self.client_id,
                "response_type": "code",
                "redirect_uri": self.redirect_uri,
                "scope": SCOPE,
                "state": state,
                "code_challenge_method": "S256",
                "code_challenge": _pkce_challenge(verifier),
            }
        )
        return f"{AUTH_URL}?{query}"

    def handle_callback(self, code: Optional[str], state: Optional[str], error: Optional[str] = None) -> None:
        if error:
            raise SpotifyError(f"Spotify refused access: {error}")
        if not code or not state:
            raise SpotifyError("Incomplete login response (code/state missing).")
        with self._lock:
            entry = self._pending.pop(state, None)
        if entry is None or self._clock() - entry["created"] > STATE_TTL:
            raise SpotifyError("Login session expired or invalid. Click 'Connect Spotify' again.")
        data = self._token_request(
            {
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": self.redirect_uri,
                "client_id": self.client_id,
                "code_verifier": entry["verifier"],  # type: ignore[dict-item]
            }
        )
        if not data.get("refresh_token"):
            raise SpotifyError("Spotify did not return a refresh_token.")
        self._store_token(data, previous=None)

    # ---------- tokens ----------
    def _token_request(self, form: dict) -> dict:
        try:
            resp = self.session.post(TOKEN_URL, data=form, timeout=30)
        except requests.RequestException as exc:
            raise SpotifyError(f"Network failure while talking to Spotify: {exc}") from exc
        if resp.status_code != 200:
            detail = ""
            try:
                body = resp.json()
                detail = body.get("error_description") or body.get("error") or ""
            except ValueError:
                pass
            raise SpotifyError(f"Spotify refused the token (HTTP {resp.status_code}): {detail}".strip())
        return resp.json()

    def _store_token(self, data: dict, previous: Optional[dict]) -> dict:
        token = {
            "access_token": data["access_token"],
            "refresh_token": data.get("refresh_token") or (previous or {}).get("refresh_token"),
            "expires_at": self._clock() + int(data.get("expires_in", 3600)),
            "scope": data.get("scope", SCOPE),
            "client_id": self.client_id,
        }
        with self._lock:
            self._token = token
            self.token_file.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.token_file.with_suffix(".tmp")
            tmp.write_text(json.dumps(token), encoding="utf-8")
            try:
                os.chmod(tmp, 0o600)
            except OSError:
                pass
            os.replace(tmp, self.token_file)
        return token

    def _load_token(self) -> Optional[dict]:
        with self._lock:
            if self._token is None and self.token_file.exists():
                try:
                    self._token = json.loads(self.token_file.read_text(encoding="utf-8"))
                except (OSError, ValueError):
                    self._token = None
            token = self._token
        if token and token.get("client_id") != self.client_id:
            return None  # token from another app
        return token

    def _access_token(self, force_refresh: bool = False) -> str:
        with self._lock:
            token = self._load_token()
            if not token or not token.get("refresh_token"):
                raise SpotifyError("Spotify is not connected. Click 'Connect Spotify'.")
            if force_refresh or token.get("expires_at", 0) - self._clock() < 60:
                data = self._token_request(
                    {"grant_type": "refresh_token", "refresh_token": token["refresh_token"], "client_id": self.client_id}
                )
                token = self._store_token(data, previous=token)
            return token["access_token"]

    # ---------- API ----------
    def _get(self, url: str, params: Optional[dict] = None) -> dict:
        refreshed = False
        for attempt in range(6):
            access = self._access_token()
            try:
                resp = self.session.get(url, headers={"Authorization": f"Bearer {access}"}, params=params, timeout=30)
            except requests.RequestException as exc:
                if attempt == 5:
                    raise SpotifyError(f"Network failure while talking to Spotify: {exc}") from exc
                self._sleep(2**attempt)
                continue
            status = resp.status_code
            if status == 401 and not refreshed:
                refreshed = True
                self._access_token(force_refresh=True)
                continue
            if status == 429:
                wait = min(int(float(resp.headers.get("Retry-After", 2))) + 1, 120)
                log.warning("Spotify 429: waiting %ss", wait)
                self._sleep(wait)
                continue
            if 500 <= status < 600:
                self._sleep(2**attempt)
                continue
            if status >= 400:
                message = ""
                try:
                    message = (resp.json().get("error") or {}).get("message", "")
                except (ValueError, AttributeError):
                    pass
                hint = ""
                if status == 403:
                    hint = " (Since Feb 2026, apps in Development Mode need the app owner to have Spotify Premium.)"
                raise SpotifyError(f"Spotify HTTP {status}: {message}{hint}".strip())
            return resp.json()
        raise SpotifyError("Spotify stayed unavailable after several attempts.")

    def saved_tracks(self, limit: Optional[int] = None, on_progress: Optional[Callable[[int, int], None]] = None) -> List[Track]:
        tracks: List[Track] = []
        url: Optional[str] = f"{API_BASE}/me/tracks"
        params: Optional[dict] = {"limit": PAGE_SIZE, "offset": 0}
        while url:
            page = self._get(url, params)
            total = int(page.get("total") or 0)
            for item in page.get("items") or []:
                track = parse_saved_item(item)
                if track is not None:
                    tracks.append(track)
                    if limit is not None and len(tracks) >= limit:
                        return tracks
            if on_progress:
                on_progress(len(tracks), total)
            url = page.get("next")
            params = None  # the `next` URL already carries the parameters
        return tracks


def parse_saved_item(item: dict) -> Optional[Track]:
    raw = (item or {}).get("track")
    if not raw or raw.get("is_local") or not raw.get("id") or not raw.get("name"):
        return None
    album = raw.get("album") or {}
    images = album.get("images") or []
    release = album.get("release_date") or ""
    duration_ms = raw.get("duration_ms")
    return Track(
        title=raw["name"],
        artists=[a["name"] for a in (raw.get("artists") or []) if a.get("name")],
        album=album.get("name"),
        duration_s=(duration_ms / 1000.0) if duration_ms else None,
        explicit=raw.get("explicit"),
        track_number=raw.get("track_number") or None,
        disc_number=raw.get("disc_number") or None,
        year=release[:4] if release[:4].isdigit() else None,
        isrc=(raw.get("external_ids") or {}).get("isrc"),
        cover_url=images[0]["url"] if images and images[0].get("url") else None,
        spotify_id=raw["id"],
        sources=["spotify"],
    )
