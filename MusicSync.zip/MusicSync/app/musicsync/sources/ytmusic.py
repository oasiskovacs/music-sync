"""Reads saved songs (library + liked) from YouTube Music through ytmusicapi."""
from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Any, Callable, List, Optional

from ..models import Track

log = logging.getLogger(__name__)

ALL = 100_000  # practical "no limit"; works the same whether the lib accepts None or only integers


class YTMusicError(RuntimeError):
    """YouTube Music error (the message is shown to the user)."""


def upscale_thumbnail(url: Optional[str], size: int = 600) -> Optional[str]:
    """Asks for the cover in a higher resolution (googleusercontent URLs end in =w226-h226-...)."""
    if not url:
        return None
    return re.sub(r"=w\d+-h\d+", f"=w{size}-h{size}", url)


def _default_client(auth_file: Path) -> Any:
    from ytmusicapi import YTMusic  # late import: only when actually used

    return YTMusic(str(auth_file))


def parse_item(item: dict, source_tag: str = "ytmusic") -> Optional[Track]:
    video_id = (item or {}).get("videoId")
    title = (item or {}).get("title")
    if not video_id or not title or item.get("isAvailable") is False:
        return None
    thumbs = item.get("thumbnails") or []
    duration = item.get("duration_seconds")
    album = item.get("album")
    return Track(
        title=title,
        artists=[a["name"] for a in (item.get("artists") or []) if a and a.get("name")],
        album=album.get("name") if isinstance(album, dict) else None,
        duration_s=float(duration) if duration else None,
        explicit=item.get("isExplicit"),
        cover_url=upscale_thumbnail(thumbs[-1].get("url")) if thumbs else None,
        video_id=video_id,
        video_type=item.get("videoType"),
        sources=[source_tag],
    )


class YTMusicSource:
    def __init__(self, auth_file: Path, client_factory: Optional[Callable[[], Any]] = None) -> None:
        self.auth_file = Path(auth_file)
        self._factory = client_factory or (lambda: _default_client(self.auth_file))

    def is_configured(self) -> bool:
        return self.auth_file.is_file()

    def clear(self) -> None:
        try:
            self.auth_file.unlink()
        except FileNotFoundError:
            pass

    def save_headers(self, headers_raw: str) -> None:
        """Validates the headers pasted by the user and only then writes the auth file."""
        headers_raw = (headers_raw or "").strip()
        if not headers_raw:
            raise YTMusicError("Paste the request headers from music.youtube.com.")
        self.auth_file.parent.mkdir(parents=True, exist_ok=True)
        previous = self.auth_file.read_bytes() if self.auth_file.exists() else None
        try:
            import ytmusicapi

            ytmusicapi.setup(filepath=str(self.auth_file), headers_raw=headers_raw)
            client = self._factory()
            client.get_library_songs(limit=1)
        except Exception as exc:  # noqa: BLE001 - any failure invalidates the headers
            if previous is not None:
                self.auth_file.write_bytes(previous)
            else:
                self.clear()
            raise YTMusicError(f"Invalid or expired headers: {exc}") from exc
        try:
            os.chmod(self.auth_file, 0o600)
        except OSError:
            pass

    def fetch(
        self, include_library: bool = True, include_liked: bool = True, limit: Optional[int] = None
    ) -> List[Track]:
        if not self.is_configured():
            raise YTMusicError("YouTube Music is not connected. Paste the headers in the connections section.")
        try:
            client = self._factory()
            raw_items: List[dict] = []
            if include_library:
                raw_items += list(client.get_library_songs(limit=ALL) or [])
            if include_liked:
                liked = client.get_liked_songs(limit=ALL) or {}
                raw_items += list(liked.get("tracks") or [])
        except Exception as exc:  # noqa: BLE001
            raise YTMusicError(f"Could not read YouTube Music: {exc}") from exc

        tracks: List[Track] = []
        seen_ids = set()
        skipped = 0
        for item in raw_items:
            track = parse_item(item)
            if track is None:
                skipped += 1
                continue
            if track.video_id in seen_ids:
                continue
            seen_ids.add(track.video_id)
            tracks.append(track)
            if limit is not None and len(tracks) >= limit:
                break
        if skipped:
            log.info("YouTube Music: %d unavailable items or items without a videoId were skipped", skipped)
        return tracks
