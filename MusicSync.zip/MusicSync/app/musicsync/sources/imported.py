"""Imported list: tracks collected outside the app (pasted text, CSV/JSON or a browser export).

Needs no login and no API key. Accepted formats:
  * text: one song per line, "Artist - Title" (numbering and bullets are ignored)
  * CSV with a header (e.g. exported by Exportify): columns like Track Name / Artist Name(s) / Album Name / Duration (ms)
  * JSON: a list of objects {"title", "artists" | "artist", "album", "duration_s", ...} or {"tracks": [...]}
"""
from __future__ import annotations

import csv
import io
import json
import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import requests

from ..models import Track

MAX_ITEMS = 50_000
MAX_TEXT_BYTES = 20 * 1024 * 1024
MAX_EXAMPLES = 5
MAX_LINKS = 5000

_TITLE_KEYS = ("title", "name", "track", "track name", "track_name", "song", "music")
_ARTIST_KEYS = ("artists", "artist", "artist name(s)", "artist name", "artist_name", "artistname")
_ALBUM_KEYS = ("album", "album name", "album_name")
_DURATION_S_KEYS = ("duration_s", "duration_seconds", "duration (s)", "seconds")
_DURATION_MS_KEYS = ("duration_ms", "duration (ms)", "duration ms")
_DURATION_KEYS = ("duration", "length", "time")
_DATE_KEYS = ("year", "release date", "release_date", "date", "album release date")
_URI_KEYS = ("track uri", "track_uri", "uri", "spotify_uri", "spotify uri", "url", "link", "spotify_id")
_VIDEO_KEYS = ("video_id", "videoid", "youtube_id", "youtube id")

_SPOTIFY_ID = re.compile(r"(?:spotify:track:|open\.spotify\.com/(?:intl-[a-z]+/)?track/)([A-Za-z0-9]{22})")
_VIDEO_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")
_VIDEO_URL = re.compile(r"[?&]v=([A-Za-z0-9_-]{11})")
_LINE_SEP = re.compile(r"\s[-–—]\s")
_LINE_PREFIX = re.compile(r"^\s*(?:\d+[.)]\s+|[-*•]\s+)")


class ImportListError(ValueError):
    """Invalid input (the message is shown to the user)."""


# ----------------------------------------------------------------------------- field helpers
def _norm_key(key: Any) -> str:
    return re.sub(r"\s+", " ", str(key or "").strip().lower())


def _pick(row: Dict[str, Any], keys: Tuple[str, ...]) -> Any:
    for key in keys:
        value = row.get(key)
        if value not in (None, "", []):
            return value
    return None


def _to_seconds(value: Any, ms: bool = False) -> Optional[float]:
    if value in (None, ""):
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        seconds = float(value)
    else:
        text = str(value).strip()
        if re.fullmatch(r"\d+(?::\d{1,2}){1,2}", text):
            seconds = 0.0
            for part in text.split(":"):
                seconds = seconds * 60 + int(part)
            return seconds if seconds > 0 else None
        try:
            seconds = float(text.replace(",", "."))
        except ValueError:
            return None
    if ms:
        seconds /= 1000.0
    return seconds if seconds > 0 else None


def _artists(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, list):
        out: List[str] = []
        for item in value:
            if isinstance(item, dict):
                item = item.get("name")
            item = str(item or "").strip()
            if item:
                out.append(item)
        return out
    return [a.strip() for a in re.split(r"\s*;\s*", str(value)) if a.strip()]


def _row_to_track(raw: Dict[str, Any]) -> Optional[Track]:
    row = {_norm_key(k): v for k, v in raw.items()}
    title = _pick(row, _TITLE_KEYS)
    artists = _artists(_pick(row, _ARTIST_KEYS))
    if not title or isinstance(title, (dict, list)) or not artists:
        return None

    duration = _to_seconds(_pick(row, _DURATION_S_KEYS))
    if duration is None:
        duration = _to_seconds(_pick(row, _DURATION_MS_KEYS), ms=True)
    if duration is None:
        duration = _to_seconds(_pick(row, _DURATION_KEYS))

    year: Optional[str] = None
    date = str(_pick(row, _DATE_KEYS) or "")
    if date[:4].isdigit():
        year = date[:4]

    spotify_id: Optional[str] = None
    for key in _URI_KEYS:
        match = _SPOTIFY_ID.search(str(row.get(key) or ""))
        if match:
            spotify_id = match.group(1)
            break

    video_id: Optional[str] = None
    candidate = str(_pick(row, _VIDEO_KEYS) or "")
    if _VIDEO_ID.match(candidate):
        video_id = candidate
    else:
        for key in _URI_KEYS:
            match = _VIDEO_URL.search(str(row.get(key) or ""))
            if match and "youtu" in str(row.get(key)):
                video_id = match.group(1)
                break

    album = _pick(row, _ALBUM_KEYS)
    isrc = str(row.get("isrc") or "").strip().upper() or None
    cover = str(row.get("cover_url") or row.get("image") or "").strip()
    return Track(
        title=str(title).strip(),
        artists=artists,
        album=str(album).strip() if album else None,
        duration_s=duration,
        year=year,
        isrc=isrc,
        cover_url=cover if cover.lower().startswith(("http://", "https://")) else None,
        spotify_id=spotify_id,
        video_id=video_id,
        sources=["import"],
    )


# ----------------------------------------------------------------------------- parsers
def _parse_line(line: str) -> Optional[Track]:
    cleaned = _LINE_PREFIX.sub("", line).strip()
    parts = _LINE_SEP.split(cleaned, maxsplit=1)
    if len(parts) != 2 or not parts[0].strip() or not parts[1].strip():
        return None
    return _row_to_track({"artist": parts[0].strip(), "title": parts[1].strip()})


_EXPORTER_HEADER = re.compile(r"^\s*\d+\s+(?:faixas?|tracks?)\s+-\s+(?:exportado em|exported on)\b", re.I)
_EXPORTER_LINE = re.compile(r"^\s*(\d{1,6})\.\s+(.+?)\s*$")


def _is_exporter_text(text: str) -> bool:
    """The "YT Music Exporter" extension writes: playlist name, "N tracks - exported on ..." (older versions: "N faixas - exportado em ..."), blank line, "001. ..."."""
    head = [line for line in text.splitlines()[:6] if line.strip()]
    return any(_EXPORTER_HEADER.match(line) for line in head[:3])


def _from_exporter(text: str) -> Tuple[List[Track], List[str]]:
    """Lines "001. Title - Artist - Album" (in that order; the album is optional)."""
    tracks: List[Track] = []
    ignored: List[str] = []
    for line in text.splitlines():
        if not line.strip() or _EXPORTER_HEADER.match(line):
            continue
        match = _EXPORTER_LINE.match(line)
        if not match:
            continue  # playlist name and the like
        parts = [p.strip() for p in match.group(2).split(" - ") if p.strip()]
        row: Dict[str, Any] = {}
        if len(parts) == 2:
            row = {"title": parts[0], "artist": parts[1]}
        elif len(parts) >= 3:  # the title may contain " - "; the last two parts are artist and album
            row = {"title": " - ".join(parts[:-2]), "artist": parts[-2], "album": parts[-1]}
        track = _row_to_track(row) if row else None
        if track is None:
            ignored.append(line.strip()[:80])
        else:
            tracks.append(track)
    return tracks, ignored


def _from_lines(text: str) -> Tuple[List[Track], List[str]]:
    tracks: List[Track] = []
    ignored: List[str] = []
    for line in text.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        track = _parse_line(line)
        if track is None:
            ignored.append(line.strip()[:80])
        else:
            tracks.append(track)
    return tracks, ignored


def _from_json(text: str) -> Tuple[List[Track], List[str]]:
    try:
        data = json.loads(text)
    except ValueError as exc:
        raise ImportListError(f"Invalid JSON: {exc}") from exc
    if isinstance(data, dict):
        data = data.get("tracks") or data.get("items") or data.get("songs") or []
    if not isinstance(data, list):
        raise ImportListError("The JSON must be a list of songs (or {\"tracks\": [...]}).")
    tracks: List[Track] = []
    ignored: List[str] = []
    for item in data:
        track = _row_to_track(item) if isinstance(item, dict) else (_parse_line(item) if isinstance(item, str) else None)
        if track is None:
            ignored.append(json.dumps(item, ensure_ascii=False)[:80])
        else:
            tracks.append(track)
    return tracks, ignored


def _from_csv(text: str, delimiter: str) -> Tuple[List[Track], List[str]]:
    tracks: List[Track] = []
    ignored: List[str] = []
    for row in csv.DictReader(io.StringIO(text), delimiter=delimiter):
        row.pop(None, None)  # colunas sobrando
        if not any(str(v or "").strip() for v in row.values()):
            continue  # completely empty row
        track = _row_to_track(row)
        if track is None:
            ignored.append(", ".join(str(v) for v in row.values() if v)[:80])
        else:
            tracks.append(track)
    return tracks, ignored


def parse_text(text: str) -> Tuple[List[Track], List[str]]:
    """Detects the format and returns (tracks, ignored_lines)."""
    text = (text or "").lstrip("﻿")
    if len(text.encode("utf-8")) > MAX_TEXT_BYTES:
        raise ImportListError("The text is too large (20 MB limit).")
    stripped = text.strip()
    if not stripped:
        raise ImportListError("Nothing to import: paste the list or choose a file.")

    if stripped[0] in "[{":
        tracks, ignored = _from_json(stripped)
    elif _is_exporter_text(stripped):
        tracks, ignored = _from_exporter(stripped)
    else:
        header = next(line for line in stripped.splitlines() if line.strip())
        delimiter = max((",", ";", "\t"), key=header.count)
        fields = [_norm_key(f) for f in next(csv.reader([header], delimiter=delimiter), [])]
        if header.count(delimiter) and any(f in _TITLE_KEYS for f in fields) and any(f in _ARTIST_KEYS for f in fields):
            tracks, ignored = _from_csv(stripped, delimiter)
        else:
            tracks, ignored = _from_lines(stripped)
    if len(tracks) > MAX_ITEMS:
        raise ImportListError(f"Too many songs ({len(tracks)}); the limit is {MAX_ITEMS}.")
    if not tracks:
        hint = f" Example of an ignored line: {ignored[0]!r}." if ignored else ""
        raise ImportListError('No songs found. Use "Artist - Title" (one per line), CSV or JSON.' + hint)
    return tracks, ignored


# ----------------------------------------------------------------------------- Spotify links
_LINK_LINE = re.compile(
    r"^\s*(?:https?://open\.spotify\.com/(?:intl-[a-z]+/)?track/|spotify:track:)([A-Za-z0-9]{22})(?:[?#/\s].*)?$"
)
_NEXT_DATA = re.compile(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', re.S)
_BROWSER_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
)


def split_spotify_links(text: str) -> Tuple[List[str], str]:
    """Splits the lines that are Spotify track links/URIs (unique ids, in order) from the rest of the text."""
    ids: List[str] = []
    seen = set()
    rest: List[str] = []
    for line in (text or "").lstrip("\ufeff").splitlines():
        match = _LINK_LINE.match(line)
        if match:
            if match.group(1) not in seen:
                seen.add(match.group(1))
                ids.append(match.group(1))
        else:
            rest.append(line)
    return ids, "\n".join(rest)


def _entity_to_track(entity: Dict[str, Any], track_id: str) -> Optional[Track]:
    name = str(entity.get("name") or entity.get("title") or "").strip()
    artists = _artists(entity.get("artists"))
    if not name or not artists:
        return None
    release = entity.get("releaseDate")
    if isinstance(release, dict):
        release = release.get("isoString")
    year = str(release)[:4] if release and str(release)[:4].isdigit() else None
    duration = entity.get("duration")
    cover: Optional[str] = None
    try:  # best effort: largest image available
        images = (entity.get("visualIdentity") or {}).get("image") or []
        best = max(images, key=lambda i: i.get("maxWidth") or 0)
        cover = best.get("url") if str(best.get("url", "")).startswith("http") else None
    except (ValueError, AttributeError, TypeError):
        cover = None
    return Track(
        title=name,
        artists=artists,
        duration_s=(float(duration) / 1000.0) if isinstance(duration, (int, float)) and duration > 0 else None,
        explicit=entity.get("isExplicit") if isinstance(entity.get("isExplicit"), bool) else None,
        year=year,
        cover_url=cover,
        spotify_id=track_id,
        sources=["import"],
    )


class SpotifyLinkResolver:
    """Turns Spotify track links into name/artist using the public embed page (no login)."""

    URL = "https://open.spotify.com/embed/track/{id}"

    def __init__(
        self,
        session: Optional[requests.Session] = None,
        workers: int = 6,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self.session = session or requests.Session()
        self.workers = workers
        self._sleep = sleep

    def resolve_one(self, track_id: str) -> Optional[Track]:
        for attempt in range(4):
            try:
                resp = self.session.get(
                    self.URL.format(id=track_id),
                    headers={"User-Agent": _BROWSER_UA, "Accept-Language": "en-US,en;q=0.8"},
                    timeout=20,
                )
            except requests.RequestException:
                self._sleep(1.5 * (attempt + 1))
                continue
            if resp.status_code == 429 or resp.status_code >= 500:
                try:
                    wait = min(float(resp.headers.get("Retry-After", 0)), 30)
                except (TypeError, ValueError):
                    wait = 0
                self._sleep(wait or 2 * (attempt + 1))
                continue
            if resp.status_code != 200:
                return None
            match = _NEXT_DATA.search(resp.text)
            if not match:
                return None
            try:
                entity = json.loads(match.group(1))["props"]["pageProps"]["state"]["data"]["entity"]
            except (ValueError, KeyError, TypeError):
                return None
            return _entity_to_track(entity, track_id) if isinstance(entity, dict) else None
        return None

    def resolve_many(
        self, ids: List[str], progress: Optional[Callable[[int, int], None]] = None
    ) -> Tuple[List[Track], List[str]]:
        """Returns (tracks in id order, ids that failed). `progress(done, total)` is called after each link."""
        counter = {"done": 0}
        lock = threading.Lock()

        def work(track_id: str) -> Optional[Track]:
            result = self.resolve_one(track_id)
            if progress is not None:
                with lock:
                    counter["done"] += 1
                    done = counter["done"]
                progress(done, len(ids))
            return result

        with ThreadPoolExecutor(max_workers=self.workers, thread_name_prefix="spotlink") as pool:
            results = list(pool.map(work, ids))
        tracks = [t for t in results if t is not None]
        failed = [i for i, t in zip(ids, results) if t is None]
        return tracks, failed


# ----------------------------------------------------------------------------- armazenamento
_FIELDS = ("title", "artists", "album", "duration_s", "year", "isrc", "cover_url", "spotify_id", "video_id")


class ImportedSource:
    """Keeps the imported list on disk (one JSON file) so it survives restarts."""

    def __init__(self, path: Path, link_resolver: Any = None) -> None:
        self.path = Path(path)
        self._lock = threading.Lock()
        self.link_resolver = link_resolver or SpotifyLinkResolver()
        self._progress: Dict[str, Any] = {"busy": False, "done": 0, "total": 0}

    def _read(self) -> List[Dict[str, Any]]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            items = data.get("tracks")
            return items if isinstance(items, list) else []
        except (OSError, ValueError, AttributeError):
            return []

    def _write(self, items: List[Dict[str, Any]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps({"version": 1, "tracks": items}, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, self.path)

    @property
    def progress(self) -> Dict[str, Any]:
        """Progress of the link reading in flight: {"busy", "done", "total"}."""
        return dict(self._progress)

    def count(self) -> int:
        with self._lock:
            return len(self._read())

    def load(self, limit: Optional[int] = None) -> List[Track]:
        with self._lock:
            items = self._read()
        tracks = [
            Track(**{k: item.get(k) for k in _FIELDS if k != "artists"}, artists=list(item.get("artists") or []), sources=["import"])
            for item in items
            if item.get("title") and item.get("artists")
        ]
        return tracks[:limit] if limit else tracks

    def add_text(self, text: str, mode: str = "append") -> Dict[str, Any]:
        if mode not in ("append", "replace"):
            raise ImportListError("mode must be 'append' or 'replace'.")
        link_ids, rest = split_spotify_links(text)
        if len(link_ids) > MAX_LINKS:
            raise ImportListError(f"Too many links ({len(link_ids)}); import them in batches of up to {MAX_LINKS}.")
        tracks: List[Track] = []
        ignored: List[str] = []
        if not link_ids:
            tracks, ignored = parse_text(rest)  # raises ImportListError if empty or without songs
        elif rest.strip():
            try:
                tracks, ignored = parse_text(rest)
            except ImportListError:
                pass  # there were only links (plus lines that are not songs)
        failed: List[str] = []
        known_ids: set = set()
        if link_ids and mode == "append":  # links stored earlier do not need to be looked up again
            with self._lock:
                known_ids = {i.get("spotify_id") for i in self._read() if i.get("spotify_id")}
        to_resolve = [i for i in link_ids if i not in known_ids]
        already = len(link_ids) - len(to_resolve)
        if to_resolve:
            self._progress = {"busy": True, "done": 0, "total": len(to_resolve)}
            try:
                resolved, failed = self.link_resolver.resolve_many(
                    to_resolve, lambda done, total: self._progress.update(done=done, total=total)
                )
            finally:
                self._progress = {"busy": False, "done": 0, "total": 0}
            tracks = resolved + tracks
            ignored = ignored + [f"link without data: {i}" for i in failed]
            if not tracks and not already:
                raise ImportListError(
                    "Could not read the Spotify links (the public page did not respond). Try again in a moment."
                )
        with self._lock:
            existing = [] if mode == "replace" else self._read()
            known = {Track(**{k: i.get(k) for k in _FIELDS if k != "artists"}, artists=list(i.get("artists") or [])).key for i in existing}
            added = 0
            for track in tracks:
                if track.key in known:
                    continue
                known.add(track.key)
                existing.append({k: getattr(track, k) for k in _FIELDS})
                added += 1
            if len(existing) > MAX_ITEMS:
                raise ImportListError(f"The list would go over {MAX_ITEMS} songs.")
            self._write(existing)
            total = len(existing)
        return {
            "added": added,
            "duplicates": len(tracks) - added,
            "total": total,
            "links": len(link_ids),
            "links_failed": len(failed),
            "ignored": len(ignored),
            "ignored_examples": ignored[:MAX_EXAMPLES],
        }

    def clear(self) -> None:
        with self._lock:
            try:
                self.path.unlink()
            except FileNotFoundError:
                pass
