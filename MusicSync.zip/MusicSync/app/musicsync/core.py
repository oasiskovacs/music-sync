"""Program core (no GUI): builds the components and exposes a simple controller."""
from __future__ import annotations

import importlib.util
import json
import logging
import os
import shutil
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from .autoimport import AutoImporter
from .config import QUALITY_MAP, Settings
from .jobs import Job, JobBusy, JobManager
from .media import find_binary
from .models import SyncRequest
from .pipeline import SyncPipeline
from .sources.imported import ImportedSource, ImportListError
from .sources.spotify import SpotifyClient
from .sources.ytmusic import YTMusicSource
from .youtube import YouTubeDownloader, YouTubeResolver

log = logging.getLogger(__name__)

MAX_LINES = 300


def js_runtime_status(settings: Settings) -> Dict[str, Any]:
    """yt-dlp needs a JavaScript runtime (Deno by default) to talk to YouTube."""
    if settings.js_runtime:
        name = settings.js_runtime.partition(":")[0].strip().lower()
        found = bool(shutil.which(name)) or ":" in settings.js_runtime
        return {"ok": found, "name": name, "hint": None if found else f"'{name}' is not on the PATH."}
    if shutil.which("deno"):
        return {"ok": True, "name": "deno", "hint": None}
    if shutil.which("node"):
        return {
            "ok": False,
            "name": "node",
            "hint": "Node was found, but yt-dlp only uses Deno by default. Set YTDLP_JS_RUNTIME=node in .env (needs Node 22+) or install Deno.",
        }
    return {"ok": False, "name": None, "hint": "Install Deno (recommended): yt-dlp needs a JS runtime for YouTube."}


@dataclass
class Core:
    settings: Settings
    imported: ImportedSource
    pipeline: SyncPipeline
    jobs: JobManager
    auto: Optional[AutoImporter]


def build_core(settings: Settings, import_dir: Optional[Path] = None) -> Core:
    imported = ImportedSource(settings.home / "imported.json")
    spotify = SpotifyClient(settings.spotify_client_id, settings.spotify_redirect_uri, settings.spotify_token_file)
    ytm = YTMusicSource(settings.ytm_auth_file)
    pipeline = SyncPipeline(settings, spotify, ytm, YouTubeResolver(), YouTubeDownloader(settings), imported=imported)
    return Core(settings, imported, pipeline, JobManager(pipeline.run), AutoImporter(imported, import_dir) if import_dir else None)


ITEM_LABELS = {
    "done": "Done",
    "skipped": "Already had",
    "would_download": "Would download",
    "not_found": "Not found",
    "failed": "Failed",
    "cancelled": "Cancelled",
    "on_hold": "On hold",
}
JOB_LABELS = {"queued": "queued", "running": "downloading", "completed": "finished", "failed": "failed", "cancelled": "cancelled"}
ITEM_STATUS_PT = {
    "pending": "waiting", "resolving": "searching", "downloading": "downloading", "tagging": "writing tags", "on_hold": "on hold",
    "done": "done", "skipped": "already had", "would_download": "would download", "not_found": "not found",
    "failed": "error", "cancelled": "cancelled",
}


def describe_import(result: Dict[str, Any]) -> str:
    text = f"{result['added']} new songs ({result['total']} on the list)"
    if result.get("links"):
        text += f", {result['links'] - result['links_failed']} of {result['links']} links read"
    if result.get("duplicates"):
        text += f", {result['duplicates']} repeated"
    if result.get("ignored"):
        text += f", {result['ignored']} lines ignored"
    if result.get("links_failed"):
        text += ". Some links failed: use Add again with the same text to retry only the missing ones"
    return text


class AppController:
    """Everything the window needs, without depending on Tkinter (so it can be tested)."""

    def __init__(
        self,
        core: Core,
        finder: Callable[..., Optional[str]] = find_binary,
        module_check: Callable[[str], bool] = lambda name: importlib.util.find_spec(name) is not None,
    ) -> None:
        self.core = core
        self._finder = finder
        self._module_check = module_check
        self.job: Optional[Job] = None
        self._add_result: Optional[Tuple[str, str]] = None
        self._add_thread: Optional[threading.Thread] = None
        self._prefs_path = core.settings.home / "gui.json"
        self.prefs = self._load_prefs()

    # ---- simple preferences (last folder and quality)
    def _load_prefs(self) -> Dict[str, str]:
        prefs = {"output_dir": self.core.settings.default_output_dir or "", "quality": self.core.settings.default_quality}
        try:
            saved = json.loads(self._prefs_path.read_text(encoding="utf-8"))
            if isinstance(saved.get("output_dir"), str) and saved["output_dir"].strip():
                prefs["output_dir"] = saved["output_dir"]
            if saved.get("quality") in QUALITY_MAP:
                prefs["quality"] = saved["quality"]
        except (OSError, ValueError, AttributeError):
            pass
        return prefs

    def _save_prefs(self) -> None:
        try:
            self._prefs_path.parent.mkdir(parents=True, exist_ok=True)
            self._prefs_path.write_text(json.dumps(self.prefs), encoding="utf-8")
        except OSError:
            log.warning("could not save the preferences", exc_info=True)

    # ---- list state
    def warnings(self) -> List[str]:
        loc = self.core.settings.ffmpeg_location
        out: List[str] = []
        if not self._module_check("yt_dlp") or not self._module_check("ytmusicapi"):
            out.append("Some program components are missing. Close this and run Start Music Sync.bat again.")
        if not (self._finder("ffmpeg", loc) and self._finder("ffprobe", loc)):
            out.append("ffmpeg is missing. Close this and run Start Music Sync.bat again (it installs it).")
        if not js_runtime_status(self.core.settings)["ok"]:
            out.append("Deno is missing. Close this and run Start Music Sync.bat again (it installs it).")
        return out

    def library_state(self) -> Dict[str, Any]:
        progress = self.core.imported.progress
        auto = self.core.auto.status() if self.core.auto else {"state": "idle", "message": ""}
        count = self.core.imported.count()
        busy = bool(progress["busy"]) or auto["state"] == "running"
        if busy:
            text = "Reading your list…"
            if progress["total"]:
                text += f" {progress['done']} of {progress['total']}"
        elif count:
            text = f"{count} songs on your list"
        else:
            text = 'Your list is empty. Click "Add songs…".'
        job_active = bool(self.job and self.job.is_active)
        return {
            "text": text,
            "count": count,
            "busy": busy,
            "can_start": count > 0 and not busy and not job_active,
            "problem": auto["message"] if auto["state"] == "error" else "",
        }

    # ---- download
    def start(self, output_dir: str, quality: str, dry_run: bool = False) -> Job:
        output_dir = (output_dir or "").strip()
        if not output_dir:
            raise ValueError("Choose the destination folder.")
        if quality not in QUALITY_MAP:
            raise ValueError("Invalid quality.")
        if self.core.imported.progress["busy"]:
            raise ValueError("Still reading your list. Please wait until it finishes.")
        if self.core.imported.count() == 0:
            raise ValueError('Your list is empty. Click "Add songs…".')
        req = SyncRequest(
            output_dir=output_dir, sources=["import"], quality=quality, dry_run=dry_run,
            workers=self.core.settings.default_workers,
        )
        try:
            self.job = self.core.jobs.submit(req.model_dump(), req)
        except JobBusy as exc:
            raise ValueError(str(exc)) from exc
        self.prefs.update(output_dir=output_dir, quality=quality)
        self._save_prefs()
        return self.job

    def cancel(self) -> None:
        if self.job and self.job.is_active:
            self.core.jobs.cancel(self.job.id)

    def job_view(self) -> Optional[Dict[str, Any]]:
        if self.job is None:
            return None
        snap = self.job.snapshot(items="summary")
        total, finished = snap["total"], snap["finished"]
        counts = snap["counts"]
        parts = [f"{label}: {counts[key]}" for key, label in ITEM_LABELS.items() if counts.get(key)]
        waiting = sum(counts.get(k, 0) for k in ("pending", "resolving", "downloading", "tagging"))
        if waiting and self.job.is_active:
            parts.append(f"Em andamento: {waiting}")
        lines: List[str] = []
        for item in snap["items"][:MAX_LINES]:
            label = ITEM_STATUS_PT.get(item["status"], item["status"])
            detail = f" — {item['message']}" if item.get("message") else ""
            lines.append(f"[{label}] {item['artist']} - {item['title']}{detail}")
        if len(snap["items"]) > MAX_LINES:
            lines.append(f"… e mais {len(snap['items']) - MAX_LINES}")
        if snap["error"]:
            lines.insert(0, f"ERRO: {snap['error']}")
        status = JOB_LABELS.get(snap["status"], snap["status"])
        anti = snap.get("anti_bot")
        if anti and anti["paused"] and self.job.is_active:
            if anti["probing"] or anti["retry_in"] <= 0:
                status = "paused: trying YouTube again now"
            else:
                minutes, seconds = divmod(int(anti["retry_in"]), 60)
                status = f"paused: YouTube anti-bot check, next try in {minutes}:{seconds:02d}"
        if total:
            status += f" — {finished} of {total}"
        return {
            "active": self.job.is_active,
            "status": snap["status"],
            "status_text": status,
            "percent": (100.0 * finished / total) if total else 0.0,
            "summary": " · ".join(parts),
            "lines": lines,
            "log": [entry["msg"] for entry in snap["logs"][-5:]],
        }

    # ---- list
    def add_text_async(self, text: str) -> None:
        if self._add_thread is not None and self._add_thread.is_alive():
            raise ValueError("Already reading a list. Please wait until it finishes.")
        if not (text or "").strip():
            raise ValueError("Paste your songs (or choose a file) before importing.")
        self._add_result = None

        def work() -> None:
            try:
                self._add_result = ("ok", describe_import(self.core.imported.add_text(text, "append")))
            except ImportListError as exc:
                self._add_result = ("err", str(exc))
            except Exception as exc:  # noqa: BLE001 - must never take the window down
                log.exception("import failed")
                self._add_result = ("err", f"Erro inesperado: {exc}")

        self._add_thread = threading.Thread(target=work, name="add-list", daemon=True)
        self._add_thread.start()

    def poll_add_result(self) -> Optional[Tuple[str, str]]:
        result, self._add_result = self._add_result, None
        return result

    def clear_list(self) -> None:
        self.core.imported.clear()
