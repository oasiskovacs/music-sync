"""Background jobs with progress that can be queried."""
from __future__ import annotations

import logging
import threading
import time
import uuid
from collections import Counter, OrderedDict, deque
from typing import Any, Callable, Deque, Dict, Optional

log = logging.getLogger(__name__)

ACTIVE_STATES = {"resolving", "downloading", "tagging", "on_hold"}
PROBLEM_STATES = {"failed", "not_found", "cancelled"}
SUMMARY_LIMIT = 500


class JobBusy(RuntimeError):
    """A job is already running."""


class Job:
    def __init__(self, job_id: str, request: Dict[str, Any]) -> None:
        self.id = job_id
        self.request = request
        self.status = "queued"
        self.error: Optional[str] = None
        self.created_at = time.time()
        self.started_at: Optional[float] = None
        self.finished_at: Optional[float] = None
        self.cancel_event = threading.Event()
        self.guard: Any = None  # BotGuard of the running job, set by the pipeline
        self._items: "OrderedDict[str, Dict[str, Any]]" = OrderedDict()
        self._logs: Deque[Dict[str, Any]] = deque(maxlen=400)
        self._lock = threading.RLock()

    # ---- writing (used by the pipeline)
    def log(self, message: str) -> None:
        log.info("[job %s] %s", self.id[:8], message)
        with self._lock:
            self._logs.append({"t": time.time(), "msg": message})

    def add_item(self, key: str, title: str, artist: str, sources: Any) -> None:
        with self._lock:
            self._items[key] = {
                "key": key,
                "title": title,
                "artist": artist,
                "sources": list(sources),
                "status": "pending",
                "message": "",
                "file": None,
                "warnings": [],
            }

    def update_item(self, key: str, **fields: Any) -> None:
        with self._lock:
            item = self._items.get(key)
            if item is not None:
                item.update(fields)

    def is_cancelled(self) -> bool:
        return self.cancel_event.is_set()

    # ---- life cycle
    def mark_running(self) -> None:
        with self._lock:
            self.status = "running"
            self.started_at = time.time()

    def finish(self) -> None:
        with self._lock:
            self.status = "cancelled" if self.cancel_event.is_set() else "completed"
            self.finished_at = time.time()

    def fail(self, message: str) -> None:
        with self._lock:
            self.status = "failed"
            self.error = message
            self.finished_at = time.time()
        self.log(f"ERRO: {message}")

    @property
    def is_active(self) -> bool:
        return self.status in ("queued", "running")

    # ---- reading
    def snapshot(self, items: str = "summary") -> Dict[str, Any]:
        with self._lock:
            all_items = list(self._items.values())
            counts = Counter(i["status"] for i in all_items)
            total = len(all_items)
            finished = total - counts.get("pending", 0) - sum(counts.get(s, 0) for s in ACTIVE_STATES)
            if items == "all":
                shown = [dict(i) for i in all_items]
            elif items == "none":
                shown = []
            else:
                shown = [
                    dict(i)
                    for i in all_items
                    if i["status"] in ACTIVE_STATES or i["status"] in PROBLEM_STATES or i["status"] == "would_download"
                ][:SUMMARY_LIMIT]
            return {
                "id": self.id,
                "status": self.status,
                "error": self.error,
                "request": self.request,
                "created_at": self.created_at,
                "started_at": self.started_at,
                "finished_at": self.finished_at,
                "total": total,
                "finished": finished,
                "counts": dict(counts),
                "items": shown,
                "logs": list(self._logs)[-100:],
                "anti_bot": self.guard.status() if self.guard is not None else None,
            }


class JobManager:
    """Runs one job at a time in its own thread."""

    def __init__(self, runner: Callable[[Job, Any], None], max_history: int = 20) -> None:
        self._runner = runner
        self._max_history = max_history
        self._jobs: "OrderedDict[str, Job]" = OrderedDict()
        self._lock = threading.Lock()

    def submit(self, request: Dict[str, Any], payload: Any) -> Job:
        with self._lock:
            if any(j.is_active for j in self._jobs.values()):
                raise JobBusy("A download job is already running. Wait for it or cancel it.")
            job = Job(uuid.uuid4().hex, request)
            self._jobs[job.id] = job
            while len(self._jobs) > self._max_history:
                oldest = next(iter(self._jobs))
                if self._jobs[oldest].is_active:
                    break
                del self._jobs[oldest]
        threading.Thread(target=self._run, args=(job, payload), name=f"job-{job.id[:8]}", daemon=True).start()
        return job

    def _run(self, job: Job, payload: Any) -> None:
        job.mark_running()
        try:
            self._runner(job, payload)
        except Exception as exc:  # noqa: BLE001
            log.exception("job %s failed", job.id)
            job.fail(str(exc) or exc.__class__.__name__)
        else:
            job.finish()

    def get(self, job_id: str) -> Optional[Job]:
        with self._lock:
            return self._jobs.get(job_id)

    def list(self) -> list:
        with self._lock:
            return [j.snapshot(items="none") for j in reversed(self._jobs.values())]

    def cancel(self, job_id: str) -> Optional[Job]:
        job = self.get(job_id)
        if job is not None and job.is_active:
            job.cancel_event.set()
            job.log("Cancelamento solicitado...")
        return job
