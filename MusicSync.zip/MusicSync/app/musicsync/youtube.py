"""YouTube: finds the right video (via YouTube Music) and downloads the best audio as MP3 (via yt-dlp)."""
from __future__ import annotations

import logging
import re
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from .config import QUALITY_MAP
from .matching import ACCEPT_THRESHOLD, rank_candidates

log = logging.getLogger(__name__)

# `bestaudio` + sorting: respect the original language (lang), then the "quality" YouTube itself assigns
# (this demotes DRC variants), then higher average bitrate and higher sample rate.
FORMAT = "bestaudio/best"
FORMAT_SORT = ["lang", "quality", "abr", "asr"]

_FEAT_BRACKET = re.compile(r"[\(\[]\s*(?:feat|ft|featuring)\b[^\)\]]*[\)\]]", re.IGNORECASE)
_ANSI = re.compile(r"\x1b\[[0-9;]*m")


def query_title(title: str) -> str:
    cleaned = re.sub(r"\s+", " ", _FEAT_BRACKET.sub(" ", title or "")).strip()
    return cleaned or (title or "")


# ----------------------------------------------------------------------------- errors
_ERROR_RULES: List[Tuple[Tuple[str, ...], str, bool]] = [
    (
        ("sign in to confirm", "not a bot"),
        "YouTube asked for its anti-bot check. Wait and retry, or set YTDLP_COOKIES_FROM_BROWSER (for example chrome) or YTDLP_COOKIES_FILE in .env.",
        True,
    ),
    (
        ("confirm your age", "age-restricted", "inappropriate for some users"),
        "Age-restricted video. Set cookies from a signed-in account (YTDLP_COOKIES_FROM_BROWSER).",
        True,
    ),
    (
        ("video unavailable", "private video", "this video is not available", "has been removed", "account associated", "no longer available", "members-only"),
        "Video unavailable on YouTube.",
        True,
    ),
    (
        ("requested format is not available", "challenge solving", "n challenge", "javascript runtime", "no supported javascript", "ejs"),
        'yt-dlp could not get the audio formats. Install Deno (or Node 22+ with YTDLP_JS_RUNTIME=node) and update: pip install -U "yt-dlp[default]".',
        True,
    ),
    (
        ("ffmpeg", "ffprobe"),
        "ffmpeg/ffprobe not found. Install ffmpeg and/or set FFMPEG_LOCATION.",
        True,
    ),
    (("http error 429", "too many requests"), "YouTube rate-limited the requests (429). Lower 'workers' or try later.", False),
    (
        ("timed out", "timeout", "connection", "network", "temporary failure", "name resolution", "ssl", "unable to download"),
        "Network failure while downloading. Try again.",
        False,
    ),
]


_BOT_BLOCK_MARKERS = ("sign in to confirm", "not a bot", "http error 429", "too many requests")


def is_bot_block(exc: BaseException) -> bool:
    """True if YouTube answered with its anti-bot check or a rate limit (HTTP 429). Both are cured by waiting."""
    low = _ANSI.sub("", str(exc) or "").lower()
    return any(marker in low for marker in _BOT_BLOCK_MARKERS)


def classify_error(exc: BaseException) -> Tuple[str, bool]:
    """Returns (friendly message in English, is_permanent)."""
    raw = _ANSI.sub("", str(exc) or exc.__class__.__name__).strip()
    low = raw.lower()
    for needles, message, permanent in _ERROR_RULES:
        if needles == ("ffmpeg", "ffprobe"):
            if any(n in low for n in needles) and ("not found" in low or "not installed" in low):
                return message, permanent
            continue
        if any(n in low for n in needles):
            return message, permanent
    return (raw[:300] or exc.__class__.__name__), False


def friendly_error(exc: BaseException) -> str:
    return classify_error(exc)[0]


# ----------------------------------------------------------------------------- busca
@dataclass
class Match:
    video_id: str
    score: float
    title: str
    query: str


def _default_search_client() -> Any:
    from ytmusicapi import YTMusic  # import tardio

    return YTMusic()


class YouTubeResolver:
    """Finds the YouTube videoId for a track, preferring the official audio
    ("Topic"/ATV), which usually has the best quality and no intro jingle."""

    def __init__(
        self,
        search_factory: Optional[Callable[[], Any]] = None,
        sleep: Callable[[float], None] = time.sleep,
        threshold: float = ACCEPT_THRESHOLD,
    ) -> None:
        self._factory = search_factory or _default_search_client
        self._sleep = sleep
        self.threshold = threshold
        self._local = threading.local()

    def _client(self) -> Any:
        client = getattr(self._local, "client", None)
        if client is None:
            client = self._factory()
            self._local.client = client
        return client

    def _search(self, query: str, flt: str) -> List[Dict[str, Any]]:
        last: Optional[Exception] = None
        for attempt in range(3):
            try:
                return list(self._client().search(query, filter=flt, limit=10, ignore_spelling=True) or [])
            except Exception as exc:  # noqa: BLE001
                last = exc
                self._local.client = None  # rebuild the client on the next attempt
                self._sleep(1.5 * (attempt + 1))
        raise RuntimeError(f"YouTube Music search failed: {last}") from last

    def resolve(self, track: Any) -> Optional[Match]:
        title = query_title(track.title)
        plans: List[Tuple[str, str]] = [("songs", f"{track.primary_artist} {title}")]
        alt = f"{title} {track.artist_text}"
        if alt != plans[0][1]:
            plans.append(("songs", alt))
        plans.append(("videos", f"{track.primary_artist} {title} audio"))

        for flt, query in plans:
            ranked = rank_candidates(track, self._search(query, flt))
            if ranked and ranked[0].score >= self.threshold:
                best = ranked[0]
                return Match(video_id=best.video_id, score=best.score, title=best.title, query=query)
        return None


# ----------------------------------------------------------------------------- download
class DownloadCancelled(Exception):
    """The user cancelled the job during the download."""


@dataclass
class Downloaded:
    path: Path
    format_id: Optional[str] = None
    abr: Optional[float] = None
    acodec: Optional[str] = None


class YouTubeDownloader:
    def __init__(self, settings: Any) -> None:
        self.ffmpeg_location = settings.ffmpeg_location
        self.cookies_file = settings.cookies_file
        self.cookies_from_browser = settings.cookies_from_browser
        self.js_runtime = settings.js_runtime
        self.remote_components = tuple(settings.remote_components)

    @staticmethod
    def url_for(video_id: str) -> str:
        return f"https://www.youtube.com/watch?v={video_id}"

    def build_opts(self, dest_dir: Path, quality: str, hook: Optional[Callable[[dict], None]] = None) -> Dict[str, Any]:
        if quality not in QUALITY_MAP:
            raise ValueError(f"invalid quality: {quality}")
        opts: Dict[str, Any] = {
            "format": FORMAT,
            "format_sort": list(FORMAT_SORT),
            # `paths` instead of building the path in outtmpl: folders with "%" in the name do not break formatting
            "outtmpl": "%(id)s.%(ext)s",
            "paths": {"home": str(dest_dir)},
            "noplaylist": True,
            "quiet": True,
            "no_warnings": True,
            "noprogress": True,
            "retries": 5,
            "fragment_retries": 5,
            "socket_timeout": 30,
            "postprocessors": [
                {"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": QUALITY_MAP[quality]}
            ],
        }
        if hook:
            opts["progress_hooks"] = [hook]
        if self.ffmpeg_location:
            opts["ffmpeg_location"] = self.ffmpeg_location
        if self.cookies_file:
            opts["cookiefile"] = self.cookies_file
        if self.cookies_from_browser:
            opts["cookiesfrombrowser"] = (self.cookies_from_browser,)
        if self.js_runtime:
            name, _, path = self.js_runtime.partition(":")
            opts["js_runtimes"] = {name.strip().lower(): ({"path": path.strip()} if path.strip() else {})}
        if self.remote_components:
            opts["remote_components"] = list(self.remote_components)
        return opts

    def download(
        self,
        video_id: str,
        dest_dir: Path,
        quality: str,
        cancel: Optional[threading.Event] = None,
        progress: Optional[Callable[[float], None]] = None,
    ) -> Downloaded:
        import yt_dlp  # import tardio

        dest_dir = Path(dest_dir)
        dest_dir.mkdir(parents=True, exist_ok=True)

        def hook(data: dict) -> None:
            if cancel is not None and cancel.is_set():
                raise DownloadCancelled()
            if progress and data.get("status") == "downloading":
                total = data.get("total_bytes") or data.get("total_bytes_estimate")
                if total:
                    progress(min(100.0, 100.0 * (data.get("downloaded_bytes") or 0) / total))

        opts = self.build_opts(dest_dir, quality, hook)
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(self.url_for(video_id), download=True)
        except DownloadCancelled:
            raise
        except Exception as exc:
            if cancel is not None and cancel.is_set():
                raise DownloadCancelled() from exc
            raise

        info = info or {}
        rd = (info.get("requested_downloads") or [{}])[0]
        path: Optional[Path] = None
        fp = rd.get("filepath") or info.get("filepath")
        if fp and Path(fp).is_file():
            path = Path(fp)
        else:
            found = sorted(dest_dir.glob("*.mp3"))
            path = found[0] if found else None
        if path is None:
            raise RuntimeError("yt-dlp finished without producing the MP3 file")
        return Downloaded(
            path=path,
            format_id=rd.get("format_id") or info.get("format_id"),
            abr=rd.get("abr") or info.get("abr"),
            acodec=rd.get("acodec") or info.get("acodec"),
        )
