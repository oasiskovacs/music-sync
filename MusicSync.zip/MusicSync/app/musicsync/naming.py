"""Standardised file names that are safe on Windows, macOS and Linux."""
from __future__ import annotations

import re
import string
import unicodedata
from pathlib import Path
from typing import Iterable, TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover
    from .models import Track

ALLOWED_FIELDS = {"artist", "primary_artist", "title", "album", "year", "track", "disc"}
DEFAULT_TEMPLATE = "{artist} - {title}"

_REPLACEMENTS = {"/": "-", "\\": "-", "|": "-", ":": " -", '"': "'"}
_REMOVE = re.compile(r"[<>?*\x00-\x1f\x7f]")
_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}


def truncate_bytes(text: str, max_bytes: int) -> str:
    """Cuts `text` to fit `max_bytes` (UTF-8) without splitting a character."""
    raw = text.encode("utf-8")
    if len(raw) <= max_bytes:
        return text
    return raw[:max_bytes].decode("utf-8", "ignore")


def sanitize_component(text: str, max_bytes: int = 150) -> str:
    """Turns text into a file/folder name that is valid on any system."""
    s = unicodedata.normalize("NFC", text or "")
    for bad, good in _REPLACEMENTS.items():
        s = s.replace(bad, good)
    s = _REMOVE.sub("", s)
    s = re.sub(r"\s+", " ", s).strip()
    s = truncate_bytes(s, max_bytes).strip(" .")
    if not s:
        return "_"
    if s.split(".")[0].upper() in _RESERVED:
        s = "_" + s
    return s


def validate_template(template: str) -> None:
    """Raises ValueError if the template has unknown fields or invalid syntax."""
    if not template or not template.strip():
        raise ValueError("filename_template cannot be empty")
    try:
        parsed = list(string.Formatter().parse(template))
    except ValueError as exc:
        raise ValueError(f"invalid filename_template: {exc}") from exc
    for _literal, field_name, spec, conv in parsed:
        if field_name is None:
            continue
        if field_name not in ALLOWED_FIELDS or spec or conv:
            allowed = ", ".join("{" + f + "}" for f in sorted(ALLOWED_FIELDS))
            raise ValueError(f"field not allowed in the template: {{{field_name}}}. Use: {allowed}")


def template_fields(track: "Track") -> dict:
    return {
        "artist": track.artist_text,
        "primary_artist": track.primary_artist,
        "title": track.title or "Unknown Title",
        "album": track.album or "Unknown Album",
        "year": track.year or "Unknown",
        "track": f"{track.track_number:02d}" if track.track_number else "",
        "disc": str(track.disc_number) if track.disc_number else "",
    }


def render_path(template: str, track: "Track", max_component_bytes: int = 150, ext: str = ".mp3") -> Path:
    """Builds the relative path (with subfolders, if the template has "/") for the track."""
    validate_template(template)
    fields = template_fields(track)
    segments = [seg for seg in re.split(r"[\\/]+", template) if seg.strip()]
    parts = [sanitize_component(seg.format(**fields), max_component_bytes) for seg in segments]
    parts[-1] = parts[-1] + ext
    return Path(*parts)


def unique_path(path: Path, taken: Iterable[Path] = ()) -> Path:
    """Appends " (2)", " (3)"... until a free name is found (on disk and among `taken`)."""
    taken_set = set(taken)
    if not path.exists() and path not in taken_set:
        return path
    n = 2
    while True:
        candidate = path.with_name(f"{path.stem} ({n}){path.suffix}")
        if not candidate.exists() and candidate not in taken_set:
            return candidate
        n += 1
