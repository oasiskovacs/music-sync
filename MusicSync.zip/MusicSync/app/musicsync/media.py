"""ffmpeg/ffprobe: MP3 check, cover art and ID3v2.3 tags (no mutagen needed)."""
from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Dict, Optional, Tuple

import requests

log = logging.getLogger(__name__)

MAX_COVER_BYTES = 8 * 1024 * 1024


class MediaError(RuntimeError):
    pass


def find_binary(name: str, location: Optional[str] = None) -> Optional[str]:
    """Looks for ffmpeg/ffprobe in `location` (folder or executable), then on the PATH."""
    if location:
        loc = Path(location).expanduser()
        candidates = [loc] if loc.is_file() else [loc / name, loc / f"{name}.exe"]
        for c in candidates:
            if c.is_file() and (name in c.name.lower()):
                return str(c)
        if loc.is_file():  # an ffmpeg path was given: look for its sibling (ffprobe)
            for sibling in (loc.with_name(name), loc.with_name(f"{name}.exe")):
                if sibling.is_file():
                    return str(sibling)
    return shutil.which(name)


def probe(path: Path, ffprobe: str) -> Dict[str, object]:
    """Reads length, codec, bitrate and tags. Raises MediaError if it is not valid audio."""
    cmd = [ffprobe, "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(path)]
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=60, check=True).stdout
        data = json.loads(out)
    except (subprocess.SubprocessError, ValueError, OSError) as exc:
        raise MediaError(f"invalid audio file: {exc}") from exc
    audio = next((s for s in data.get("streams", []) if s.get("codec_type") == "audio"), None)
    if audio is None:
        raise MediaError("the downloaded file has no audio stream")
    fmt = data.get("format", {})
    try:
        duration = float(fmt.get("duration") or audio.get("duration") or 0)
    except ValueError:
        duration = 0.0
    bit_rate = fmt.get("bit_rate") or audio.get("bit_rate")
    return {
        "duration": duration,
        "codec": audio.get("codec_name"),
        "bit_rate": int(bit_rate) if bit_rate else None,
        "has_cover": any(s.get("codec_type") == "video" for s in data.get("streams", [])),
        "tags": {k.lower(): v for k, v in (fmt.get("tags") or {}).items()},
    }


def fetch_cover(url: str, session: Optional[requests.Session] = None) -> Optional[Tuple[bytes, str]]:
    """Downloads the cover. Returns (bytes, extension) or None on failure (a cover is never required)."""
    if not url or not url.lower().startswith(("http://", "https://")):
        return None
    try:
        resp = (session or requests).get(url, timeout=20, stream=False)
        if resp.status_code != 200:
            return None
        data = resp.content
    except requests.RequestException as exc:
        log.warning("cover unavailable (%s): %s", url, exc)
        return None
    if not data or len(data) > MAX_COVER_BYTES:
        return None
    if data[:3] == b"\xff\xd8\xff":
        return data, "jpg"
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return data, "png"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return data, "webp"
    return None


def build_metadata(track) -> Dict[str, str]:
    meta = {"title": track.title, "artist": track.artist_text}
    if track.artists:
        meta["album_artist"] = track.artists[0]
    if track.album:
        meta["album"] = track.album
    if track.track_number:
        meta["track"] = str(track.track_number)
    if track.disc_number:
        meta["disc"] = str(track.disc_number)
    if track.year:
        meta["date"] = str(track.year)
    if track.isrc:
        meta["TSRC"] = track.isrc
    return meta


def write_tags(
    ffmpeg: str,
    src: Path,
    dst: Path,
    meta: Dict[str, str],
    cover: Optional[Tuple[bytes, str]] = None,
) -> None:
    """Copies the audio from `src` to `dst` (no re-encode) with ID3v2.3 tags and an optional cover."""
    cover_path: Optional[Path] = None
    try:
        cmd = [ffmpeg, "-y", "-v", "error", "-i", str(src)]
        if cover:
            data, ext = cover
            fd, name = tempfile.mkstemp(suffix=f".{ext}", dir=str(dst.parent))
            with os.fdopen(fd, "wb") as fh:
                fh.write(data)
            cover_path = Path(name)
            vcodec = "copy" if ext in ("jpg", "png") else "mjpeg"
            cmd += ["-i", str(cover_path), "-map", "0:a", "-map", "1:v", "-c:a", "copy", "-c:v", vcodec]
            cmd += ["-metadata:s:v", "title=Album cover", "-metadata:s:v", "comment=Cover (front)"]
        else:
            cmd += ["-map", "0:a", "-c:a", "copy"]
        cmd += ["-map_metadata", "-1", "-id3v2_version", "3"]
        for key, value in meta.items():
            cmd += ["-metadata", f"{key}={value}"]
        cmd += ["-f", "mp3", str(dst)]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        if result.returncode != 0 or not dst.is_file() or dst.stat().st_size == 0:
            raise MediaError((result.stderr or "ffmpeg failed").strip()[-400:])
    finally:
        if cover_path is not None:
            try:
                cover_path.unlink()
            except OSError:
                pass
