"""Per-folder index: remembers what was already downloaded so running again does nothing twice."""
from __future__ import annotations

import json
import logging
import os
import threading
import time
from pathlib import Path
from typing import Dict, Optional

log = logging.getLogger(__name__)

INDEX_NAME = ".musicsync-index.json"
FLUSH_INTERVAL = 2.0


class DownloadIndex:
    def __init__(self, folder: Path) -> None:
        self.folder = Path(folder)
        self.path = self.folder / INDEX_NAME
        self._lock = threading.Lock()
        self._dirty = False
        self._last_flush = 0.0
        self._tracks: Dict[str, dict] = {}
        self._load()

    def _load(self) -> None:
        if not self.path.exists():
            return
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            tracks = data.get("tracks")
            if not isinstance(tracks, dict):
                raise ValueError("formato inesperado")
            self._tracks = tracks
        except (OSError, ValueError) as exc:
            backup = self.path.with_name(self.path.name + f".corrompido-{int(time.time())}")
            log.warning("unreadable index (%s); moving it to %s and starting over", exc, backup.name)
            try:
                os.replace(self.path, backup)
            except OSError:
                pass
            self._tracks = {}

    def get(self, key: str) -> Optional[dict]:
        with self._lock:
            entry = self._tracks.get(key)
            return dict(entry) if entry else None

    def existing_file(self, key: str) -> Optional[Path]:
        """File recorded for `key`, if it still exists on disk."""
        entry = self.get(key)
        if not entry or not entry.get("file"):
            return None
        candidate = self.folder / entry["file"]
        return candidate if candidate.is_file() else None

    def record(self, key: str, **fields) -> None:
        with self._lock:
            self._tracks[key] = fields
            self._dirty = True
        self.flush()

    def flush(self, force: bool = False) -> None:
        with self._lock:
            if not self._dirty:
                return
            if not force and time.monotonic() - self._last_flush < FLUSH_INTERVAL:
                return
            payload = json.dumps({"version": 1, "tracks": self._tracks}, ensure_ascii=False, indent=1)
            tmp = self.path.with_name(self.path.name + ".tmp")
            tmp.write_text(payload, encoding="utf-8")
            os.replace(tmp, self.path)
            self._dirty = False
            self._last_flush = time.monotonic()

    def __len__(self) -> int:
        with self._lock:
            return len(self._tracks)
