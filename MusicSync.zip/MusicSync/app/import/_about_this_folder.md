Put .txt, .csv or .json files in this folder. They are read when the program opens.
After a file is read, it is renamed to <name>.imported so it is not read twice.
Accepted lines: Spotify track links, or "Artist - Title".
Files exported by the Firefox extension are recognised too.
