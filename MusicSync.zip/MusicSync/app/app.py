#!/usr/bin/env python3
"""Music Sync: desktop program with a window. Start it with Start Music Sync.bat (or: python app.py)."""
from __future__ import annotations

import logging
import sys
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
LOG_FILE = HERE / "musicsync.log"


def _fail(message: str) -> None:
    """Shows the error in a window (if possible), on the console and in the log file."""
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as fh:
            fh.write(message + "\n")
    except OSError:
        pass
    print(message, file=sys.stderr)
    try:
        import tkinter
        from tkinter import messagebox

        root = tkinter.Tk()
        root.withdraw()
        messagebox.showerror("Music Sync", f"{message[-900:]}\n\nDetails in: {LOG_FILE}")
        root.destroy()
    except Exception:  # noqa: BLE001 - without tkinter, the console/log is what is left
        pass


def main() -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        handlers=[logging.FileHandler(LOG_FILE, encoding="utf-8")],
    )
    sys.path.insert(0, str(HERE))
    try:
        from musicsync.gui import run_gui
    except ModuleNotFoundError as exc:
        _fail(f"A component is missing ({exc.name}). Close this and run Start Music Sync.bat again.")
        return 1
    try:
        run_gui(HERE)
    except Exception:  # noqa: BLE001
        _fail(traceback.format_exc())
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
