@echo off
setlocal
cd /d "%~dp0app"
title Music Sync

where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found.
  echo Install Python 3.10 or newer from https://www.python.org/downloads/
  echo During setup, tick "Add python.exe to PATH", then run this file again.
  pause
  exit /b 1
)
python -c "import tkinter" >nul 2>nul
if errorlevel 1 (
  echo This Python install has no Tkinter, so the window cannot open.
  echo Run the Python installer again, choose Modify, and tick "tcl/tk and IDLE".
  pause
  exit /b 1
)

set NEEDRESTART=0
where ffmpeg >nul 2>nul
if errorlevel 1 (
  echo Installing ffmpeg with winget...
  winget install --id Gyan.FFmpeg -e --accept-source-agreements --accept-package-agreements
  set NEEDRESTART=1
)
where deno >nul 2>nul
if errorlevel 1 (
  where node >nul 2>nul
  if errorlevel 1 (
    echo Installing Deno with winget...
    winget install --id DenoLand.Deno -e --accept-source-agreements --accept-package-agreements
    set NEEDRESTART=1
  )
)
if "%NEEDRESTART%"=="1" (
  echo.
  echo Setup finished. Close this window and double-click this file again.
  pause
  exit /b 0
)

if not exist ".venv\Scripts\python.exe" (
  echo First run: preparing the program. This takes a minute.
  python -m venv .venv
  if errorlevel 1 ( echo Could not create the Python environment. & pause & exit /b 1 )
)
".venv\Scripts\python.exe" -m pip install --quiet -r requirements.txt
if errorlevel 1 ( echo Could not install the requirements. & pause & exit /b 1 )
rem yt-dlp breaks when YouTube changes; keep it current (failure here is not fatal).
".venv\Scripts\python.exe" -m pip install --quiet -U "yt-dlp[default]" >nul 2>nul

if not exist "import" mkdir import

rem One-time desktop shortcut with the program icon.
powershell -NoProfile -Command "$d=[Environment]::GetFolderPath('Desktop'); $p=Join-Path $d 'Music Sync.lnk'; if(-not (Test-Path $p)){ $s=(New-Object -ComObject WScript.Shell).CreateShortcut($p); $s.TargetPath=(Join-Path '%CD%' '.venv\Scripts\pythonw.exe'); $s.Arguments='app.py'; $s.WorkingDirectory='%CD%'; $s.IconLocation=(Join-Path '%CD%' 'assets\icon.ico'); $s.Save() }" >nul 2>nul

start "" ".venv\Scripts\pythonw.exe" app.py
exit /b 0
