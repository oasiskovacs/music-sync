# Music Sync

A small Windows program that takes your song lists (Spotify links, YouTube Music playlists, plain text), finds each song on YouTube, saves it as an MP3 and names the file `Artist - Title.mp3`.

**To run it:** double-click `Start Music Sync.bat`. Everything else lives in the `app` folder.

**Read the [disclaimer](#disclaimer) before using it.**

Contents: [Tutorial](#tutorial) · [YouTube Music playlists (Firefox extension)](#firefox-extension) · [Disclaimer](#disclaimer)

---

<a id="tutorial"></a>
## Tutorial

Music Sync reads a list of songs, looks each one up on YouTube, downloads the audio as MP3 and saves it as `Artist - Title.mp3` in a folder you pick. Run it twice and it skips what it already has.

Please read the [disclaimer](#disclaimer) first. Downloading music is not always allowed, and that part is on you.

### What you need

- Windows 10 or 11.
- Python 3.10 or newer from python.org. In the installer, tick **Add python.exe to PATH** and keep **tcl/tk and IDLE** selected.
- An internet connection.
- ffmpeg (converts audio to MP3) and Deno (lets yt-dlp read YouTube pages). You do not install these by hand. The start file does it through winget, which comes with current Windows.

### First run

1. Unzip the folder somewhere you will keep it, for example `Documents\MusicSync`.
2. Double-click **Start Music Sync.bat**.
3. If it installs ffmpeg or Deno, it will tell you to close the window and run the file again. Do that once.
4. The first start creates a private Python environment and installs a few packages. It takes about a minute.
5. The window opens. A shortcut called **Music Sync** (with the icon) appears on your Desktop. Use that from now on.

### Getting your songs in

You can mix sources. Everything goes into one list.

#### From Spotify

1. Open the Spotify desktop app and go to the playlist or to Liked Songs.
2. Click any song, press **Ctrl+A** to select all, then **Ctrl+C**.
3. Paste into a text file. You should see one `https://open.spotify.com/track/...` link per song.
4. Save the file as `.txt` in the `app\import` folder, or use the add button described below.

The program reads the title, artist, length and release year from each link. No Spotify login is needed. With a big list this takes a few minutes the first time, because it asks Spotify about every song. The result is saved, so it does not repeat.

#### From YouTube Music

Use the Firefox extension. Steps are in the [Firefox extension](#firefox-extension) section. It gives you a `.txt` file; drop it into `app\import`.

#### From anything else

Plain text works. One song per line: `Artist - Title`. CSV and JSON files with columns like `artist` and `title` also work.

#### Two ways to add a list

- **Folder:** put the files in `app\import`. They are read when the program opens, then renamed to `.imported`.
- **Button:** click **Add songs…**. Paste text or click **Choose file…**, then **Import**.

### Downloading

1. Check the line at the top of the window. It says how many songs are on your list.
2. **Destination folder:** the default is `Music\MusicSync` in your user folder. Click **Change…** to pick another.
3. **MP3 quality:** 320k is the highest. V0 is variable bitrate (about 245 kbps on average): smaller files, and most people cannot hear the difference from 320k.
4. Tick **Simulate only (downloads nothing)** for the first run. It searches YouTube and shows which songs it would download and which it cannot find, without saving anything.
5. Click **Download all**.

A progress bar and a log show what is happening. **Cancel** stops the job; files already finished stay.

### If YouTube blocks the downloads

Now and then YouTube answers with its "confirm you're not a bot" check, or says you made too many requests. Music Sync does not try to solve or get around that check. It waits and tries again:

1. The blocked song is marked **On hold** and the program carries on with the next songs.
2. When the rest of the list is done, the songs on hold are tried again.
3. If YouTube blocks 3 downloads in a row, all downloads pause. The status line says "paused: YouTube anti-bot check, next try in 1:45".
4. After the countdown, the program tries one download. If it works, everything resumes by itself. If it is blocked again, it waits longer: 2, 5, 10, 15 and then 30 minutes between tries.
5. After 12 failed tries in a row (about 4.5 hours) it stops waiting. The songs still on hold are marked as failed. Run it again later; finished songs are skipped.

You can click **Cancel** at any time, including during a pause. If blocks happen all the time, wait a few hours between runs. Signing in with your browser's YouTube cookies is also possible through yt-dlp (`YTDLP_COOKIES_FROM_BROWSER` in a `.env` file inside the `app` folder), but it ties the downloads to your Google account, so think about that first.

### What you get

- Files named `Artist - Title.mp3`. Japanese, Russian and other alphabets are kept as they are. Characters Windows does not allow in names (`: ? " / \ |`) are replaced.
- ID3 tags (title, artist, album, year) and cover art when the list had them.
- Re-running is safe. Songs already downloaded are skipped.

### Clear list

**Clear list** empties the list inside the program. It does not delete any MP3.

### Where things are stored

| What | Where |
| --- | --- |
| Your list and settings | `C:\Users\<you>\.musicsync` |
| Log file | `app\musicsync.log` |
| MP3 files | The folder you chose |

### When something goes wrong

- **The window does not open.** Open `musicsync.log`. If it mentions Tkinter, rerun the Python installer, choose Modify and tick tcl/tk.
- **Red warning about ffmpeg or Deno.** Run `Start Music Sync.bat` again. If winget is not available on your machine, install both by hand and restart Windows.
- **Many songs say "not found".** Try the simulation again later. YouTube changes often and yt-dlp needs updates; the start file updates it every time you open the program. Also check that those lines are real `Artist - Title` pairs.
- **A Spotify link fails.** The program retries three times and keeps the failed ones for the next start. Spotify sometimes rate-limits large lists.
- **Wrong song downloaded.** The match is automatic. It compares title, artist and length and rejects results more than 15 seconds off. Live versions and remixes can still slip through. Delete the file and download that one by hand.
- **Stopped in the middle of a job.** Run it again. Songs that finished are skipped; the rest are tried again. This is covered by the project's tests, but I have not tested a hard shutdown on a real machine.

### Limits

- One job at a time.
- Spotify links only read single tracks. Album and playlist links are not expanded.
- Quality depends on the YouTube source. A 320k MP3 made from a lower quality YouTube stream is still a lower quality recording.

---

<a id="firefox-extension"></a>
## Firefox extension: YT Music Exporter

A small extension that saves a YouTube Music playlist, including Liked Songs, as a `.txt` file that Music Sync can read.

### What it does

When you click the button, it scrolls the playlist page until every song has loaded, collects the title, artist, album and length of each row, and saves a text file to your browser's download folder. It stops scrolling when the song count has not grown for five checks in a row (about six seconds).

It works only on `music.youtube.com`, and the page must be open and logged in. It has one permission (`activeTab`). Reading the source in `app\extension\src` shows it makes no network requests: the file is built in the page and handed to the browser as a normal download.

### Install

The extension is not signed by Mozilla, so regular Firefox only loads it temporarily.

**Temporary install (works in any Firefox):**

1. Type `about:debugging` in the address bar.
2. Click **This Firefox**.
3. Click **Load Temporary Add-on…** and pick `app\extension\ytmusic-exporter.xpi`.
4. It stays until you close Firefox. Repeat these steps next time.

**Permanent install:** Firefox Developer Edition, Nightly or ESR can run unsigned add-ons. Open `about:config`, set `xpinstall.signatures.required` to `false`, then open the `.xpi` file in that browser. Regular Firefox does not honour this setting.

### Use

1. Open [music.youtube.com](https://music.youtube.com) and log in.
2. Open the playlist, or Liked Songs from the Library tab.
3. Click the extension icon in the toolbar, then **Export playlist**.
4. Keep the tab open and visible. The popup shows `Loading tracks... N` while it scrolls. Big playlists take a few minutes.
5. When it says `Done!`, the file is in your browser's download folder, named after the playlist (`Liked_Songs.txt`, for example).
6. Move that file into the `app\import` folder of Music Sync.

### What the file looks like

```
Playlist name
3 tracks - exported on 11/7/2026, 9:30:00 AM

001. Song title - Artist - Album
002. Another song - Artist
003. Third song - Artist - Album
```

Music Sync recognises this layout (and the older Portuguese header, `N faixas - exportado em`, from version 1.0 of the extension). Title comes first, then artist, then album if there is one. Note that this is the reverse of the plain-text format (`Artist - Title`), which is why Music Sync checks the header line before reading it.

### Problems

- **"Open a music.youtube.com tab first."** The active tab is not YouTube Music.
- **"Could not reach the page."** Reload the YouTube Music tab (F5) and try again. This happens right after installing.
- **"No tracks found."** Open an actual playlist page and check that you are logged in.
- **Fewer songs than expected.** Songs YouTube has removed or made unavailable may show with no title and are skipped. If the count looks low, run the export again with the tab in front.
- **Song titles that contain " - "** (for example `Song - Live`) are handled when an album is present. Without an album, such a title may split wrong, and the song might not be found. The log tells you which lines failed.

---

<a id="disclaimer"></a>
## Disclaimer

Please read this before you use Music Sync or share it.

### What this program is

Music Sync automates steps you could do by hand: read a list, search YouTube, save the audio, rename the file. It does not contain music, host music or provide a catalogue. It uses other people's software and websites to do the work, and what you point it at is your decision.

### Copyright and what you are allowed to download

Most commercial music is protected by copyright, and the YouTube streams of it are no exception.

- **YouTube's terms** let you watch and stream. They do not let you download content unless YouTube offers a download button for it. Using this program on YouTube content can break those terms, and YouTube can block or terminate accounts and IP addresses for it.
- **Copyright law** differs by country. In Brazil, Law 9.610/1998 allows copying only small excerpts of a work for private use. It does not give a general right to copy a full commercial recording. Several countries have private-copy exceptions, often tied to a levy and often limited to media you own. Others have none. Do not assume "personal use" is automatically legal where you live.
- **Spotify's terms** restrict collecting data from its service outside its official tools. This program reads public song information from links you give it. Whether that is acceptable for you is for you to judge under their terms.

Use this program only with music you have the right to download: your own recordings, music under a licence that allows it (Creative Commons, public domain), or music the artist or label has said you may download. If you are unsure, do not use it.

This is general information, not legal advice. Talk to a lawyer if the details matter to you.

### Your responsibility

You are responsible for what you download and what you do with it. The author does not endorse infringing copyright. Do not sell, share or upload the downloaded files.

### No affiliation

Music Sync is an independent project. It is not made, approved or sponsored by Spotify, Google, YouTube or YouTube Music. Those names and logos belong to their owners.

### No warranty

The program is provided as is, without any warranty. Websites change without notice, so it can stop working at any time. The author is not liable for lost files, blocked accounts, legal claims or any other damage that comes from using it. If you do not accept that, do not use the program.

### Privacy

- No account, no password and no API key is requested or stored.
- Your list and settings stay on your computer, in `C:\Users\<you>\.musicsync`.
- The program contacts Spotify's public song pages to read song details and YouTube to search and download. The author receives nothing.
- The Firefox extension runs only on music.youtube.com and makes no network requests.

### Software it relies on

| Software | Licence |
| --- | --- |
| yt-dlp | Unlicense (public domain) |
| ytmusicapi | MIT |
| Requests | Apache 2.0 |
| Pydantic | MIT |
| python-dotenv | BSD 3-Clause |
| FFmpeg (installed separately by winget, not included here) | LGPL or GPL, depending on the build |
| Deno (installed separately by winget, not included here) | MIT |

Each of these has its own terms and none of their authors endorse this project.
